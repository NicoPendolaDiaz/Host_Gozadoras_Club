"""Entrada revisada del paquete mínimo. Motor V12 adaptado al contrato de entrada V4."""
import argparse
import json
import math
import hashlib
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MAX_REQUEST_BYTES = 8 * 1024 * 1024
EXPECTED_FINGERPRINT = '0403072e8346fab21f66bc2e51c197e64d73f7743defb95072f3bb95b7b6ab74'

class InputError(ValueError):
    def __init__(self, code, fields=()):
        self.code, self.fields = code, list(fields)

class SafeArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        # argparse's default error echoes arguments; never reflect caller data.
        raise InputError('CLI_ARGUMENTS_INVALID')

class EngineError(RuntimeError):
    pass

def _unique_keys(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise InputError('DUPLICATE_JSON_KEY')
        obj[key] = value
    return obj

def _invalid_number(value):
    raise InputError('NONSTANDARD_JSON_NUMBER')

def _finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise InputError('NONSTANDARD_JSON_NUMBER')
    return result

def read_request(path=None):
    try:
        if path:
            with Path(path).open(encoding='utf-8-sig') as stream:
                raw = stream.read(MAX_REQUEST_BYTES + 1)
        else:
            raw = sys.stdin.read(MAX_REQUEST_BYTES + 1)
        if len(raw.encode('utf-8')) > MAX_REQUEST_BYTES:
            raise InputError('REQUEST_TOO_LARGE')
        # Un BOM de Windows no forma parte del contenido de las respuestas.
        return json.loads(raw.removeprefix('\ufeff'), object_pairs_hook=_unique_keys,
                          parse_constant=_invalid_number, parse_float=_finite_float)
    except InputError:
        raise
    except (ValueError, UnicodeError, RecursionError):
        raise InputError('INVALID_JSON') from None
    except OSError:
        raise InputError('INPUT_FILE_UNREADABLE') from None

def load_engine():
    # Los módulos originales usan la codificación predeterminada al leer sus
    # catálogos. La CLI arranca en UTF-8 antes de importarlos, también en Windows.
    sys.path.insert(0, str(ROOT / 'motor'))
    try:
        manifest = json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
        for name in ('motor/composer.py', 'motor/qa.py', 'motor/canonical_options.json',
                     'motor/composition_catalog.json', 'contrato_instrumento_v4.json',
                     'GOZADORAS_Mapa_Experiencia_40_Preguntas_V4.docx'):
            expected = manifest['file_sha256'].get(name)
            if not expected or hashlib.sha256((ROOT/name).read_bytes()).hexdigest() != expected:
                raise EngineError('ENGINE_PACKAGE_INTEGRITY_ERROR')
        import composer
        import qa
        if composer.INSTRUMENT_FINGERPRINT != EXPECTED_FINGERPRINT:
            raise EngineError('ENGINE_CATALOGUE_MISMATCH')
        return composer, qa
    except EngineError:
        raise
    except Exception:
        raise EngineError('ENGINE_LOAD_ERROR') from None

def process_request(request, engine, validator):
    error = validator.request_error(request, schema=engine.SNAPSHOT_SCHEMA,
                                    fingerprint=engine.INSTRUMENT_FINGERPRINT,
                                    composition_version=engine.VERSION)
    if error:
        raise InputError(*error)
    result = engine.compose_session(request)
    output = result.get('output', {})
    if result.get('production_delivery') is not False or output.get('delivery_eligible') is not False:
        raise EngineError('DELIVERY_GUARD_FAILED')
    if output.get('status') not in {'DRAFT_EDITORIAL_REVIEW', 'EXTENDED_DRAFT_EDITORIAL_REVIEW', 'RECOMPOSITION_REQUIRED'}:
        raise EngineError('OUTPUT_STATUS_INVALID')
    return result

def main():
    # Reejecutar antes de cargar el motor evita catálogos mal decodificados en
    # sistemas cuya codificación predeterminada no es UTF-8.
    if not sys.flags.utf8_mode:
        try:
            return subprocess.run([sys.executable, '-X', 'utf8', str(Path(__file__).resolve()), *sys.argv[1:]]).returncode
        except (OSError, UnicodeError, ValueError):
            print(json.dumps({'status':'ENGINE_ERROR','code':'UTF8_STARTUP_FAILED','production_delivery':False}), file=sys.stderr)
            return 3
    for stream in (sys.stdin,sys.stdout,sys.stderr):
        if hasattr(stream,'reconfigure'):
            stream.reconfigure(encoding='utf-8')
    parser = SafeArgumentParser(description='Motor compatible con las 40 preguntas V4 — composición para revisión editorial')
    parser.add_argument('entrada', nargs='?', help='Archivo JSON UTF-8; sin argumento, leer stdin')
    try:
        args = parser.parse_args()
        request = read_request(args.entrada)
        engine, validator = load_engine()
        result = process_request(request, engine, validator)
        encoded = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
    except InputError as exc:
        print(json.dumps({'status':'INPUT_OR_CONTRACT_ERROR','code':exc.code,
                          'fields':exc.fields,'production_delivery':False}),file=sys.stderr)
        return 2
    except EngineError as exc:
        print(json.dumps({'status':'ENGINE_ERROR','code':str(exc),'production_delivery':False}),file=sys.stderr)
        return 3
    except Exception:
        print(json.dumps({'status':'ENGINE_ERROR','code':'ENGINE_EXECUTION_FAILED','production_delivery':False}),file=sys.stderr)
        return 3
    try:
        print(encoded)
    except (OSError, UnicodeError):
        print(json.dumps({'status':'ENGINE_ERROR','code':'OUTPUT_WRITE_FAILED','production_delivery':False}),file=sys.stderr)
        return 3
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
