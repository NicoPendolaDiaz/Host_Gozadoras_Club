"""Pruebas reproducibles del paquete mínimo; no aprobación editorial."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent

def main():
    checks=[]
    def check(name, condition):
        if not condition:raise RuntimeError(name)
        checks.append(name)
    manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    names={str(p.relative_to(ROOT)).replace(os.sep,'/') for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.json'}
    check('Inventario exacto de archivos',names==set(manifest['file_sha256']))
    check('Integridad SHA256',all(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h for n,h in manifest['file_sha256'].items()))
    request=json.loads((ROOT/'ejemplo_entrada.json').read_text(encoding='utf-8'))
    expected=json.loads((ROOT/'ejemplo_salida.json').read_text(encoding='utf-8'))
    def call(value=None,raw=None,args=(),cwd=ROOT,env=None):
        return subprocess.run([sys.executable,str(ROOT/'ejecutar.py'),*args],
            input=raw if raw is not None else json.dumps(value,ensure_ascii=False),
            text=True,encoding='utf-8',capture_output=True,cwd=cwd,env=env,timeout=30)
    def accepted(name,p,expected_result=None):
        check(name,p.returncode==0 and not p.stderr.strip() and json.loads(p.stdout)==(expected if expected_result is None else expected_result))
    def rejected(name,value=None,raw=None,code=None):
        p=call(value,raw)
        check(name,p.returncode==2 and not p.stdout.strip())
        error=json.loads(p.stderr)
        check(name+' devuelve error seguro',error['status']=='INPUT_OR_CONTRACT_ERROR' and error['production_delivery'] is False and (code is None or error['code']==code) and 'PRIVATE_TEST_SENTINEL' not in p.stderr)
    accepted('Ejemplo reproducible por stdin',call(request))
    accepted('Ejemplo reproducible por archivo',call(args=(str(ROOT/'ejemplo_entrada.json'),)))
    check('Entrega pública bloqueada',expected['production_delivery'] is False and expected['output']['delivery_eligible'] is False)
    with tempfile.TemporaryDirectory(prefix='motor_ñ_') as temp:
        accepted('Ejecución desde otra carpeta',call(request,cwd=temp))
        file=Path(temp)/'entrada_á.json'
        file.write_text(json.dumps(request,ensure_ascii=False),encoding='utf-8-sig')
        accepted('Archivo UTF8 con BOM y ruta acentuada',call(args=(str(file),),cwd=temp))
        env=dict(os.environ,PYTHONUTF8='0',PYTHONIOENCODING='ascii',LC_ALL='C',PYTHONCOERCECLOCALE='0')
        accepted('Inicio con codificación ASCII',call(request,cwd=temp,env=env))
    for name,field in [('Esquema incompatible','snapshot_schema'),('Huella incompatible','instrument_fingerprint'),('Composición incompatible','composition_version')]:
        bad=copy.deepcopy(request);bad[field]='INCOMPATIBLE';rejected(name,bad,code='CONTRACT_VERSION_MISMATCH')
    bad=copy.deepcopy(request);bad['snapshot']['session_id']='OTHER';rejected('Sesiones distintas',bad,code='SESSION_ID_MISMATCH')
    bad=copy.deepcopy(request);bad['snapshot']['rules_version']='OTHER';rejected('Reglas distintas',bad,code='RULES_VERSION_MISMATCH')
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P17']={'option_ids':['P17_O01'],'zone_ids':[],'state_code':'answered','text':None};rejected('Respuesta en rama inactiva',bad)
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P28']={'option_ids':[],'zone_ids':[],'state_code':'omitted','text':None};rejected('Pregunta necesaria omitida',bad)
    good=copy.deepcopy(request);good['snapshot']['answers']['P08']['option_ids']=['P08_O06'];p=call(good);check('Ausencia P08 compatible',p.returncode==0 and json.loads(p.stdout)['response_records']==good['snapshot']['answers'])
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P24']={'option_ids':['P24_O17'],'zone_ids':[],'state_code':'answered','text':None};bad['snapshot']['answers']['P28']={'option_ids':[],'zone_ids':[],'state_code':'not_shown','text':None};p=call(bad);check('Estado P24 compatible con V4',p.returncode==0 and json.loads(p.stdout)['response_records']==bad['snapshot']['answers'])
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P15']={'option_ids':['P15_O09'],'zone_ids':[],'state_code':'answered','text':None};rejected('Privacidad convertida a answered',bad)
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P01']['option_ids']=['P01_O01','P01_O01'];rejected('Opciones repetidas',bad)
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P11']['zone_ids']=['Z99'];rejected('Zona desconocida',bad)
    for name,value in [('Solicitud nula',None),('Solicitud lista',[]),('Solicitud texto','PRIVATE_TEST_SENTINEL')]:
        rejected(name,value)
    for name,raw in [('JSON incompleto','{'),('Clave JSON repetida','{"session_id":"PRIVATE_TEST_SENTINEL","session_id":"OTHER"}'),('Número NaN','{"x":NaN}'),('Número Infinity','{"x":Infinity}')]:
        rejected(name,raw=raw)
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P11']['state_code']='PRIVATE_TEST_SENTINEL';rejected('Error no expone contenido',bad)
    # Un texto literal no aporta opciones, relaciones ni interpretaciones nuevas.
    sys.path.insert(0,str(ROOT/'motor'))
    import composer
    literal='  Quiero cercanía y alegría <b>sin interpretar</b>\nCon mis palabras.  '
    bad=copy.deepcopy(request);bad['snapshot']['answers']['P23'].update(state_code='answered',text=literal)
    obj=composer.compile_object(bad['snapshot'])
    check('Texto literal preservado',obj['literal_text']['P23']==literal)
    expected_literal=copy.deepcopy(expected);expected_literal['response_records']=bad['snapshot']['answers'];accepted('Texto libre no altera el borrador y se conserva',call(bad),expected_literal)
    # Fronteras reales de obligatoriedad y cadena de activación del módulo original.
    import qa
    optional=copy.deepcopy(request['snapshot'])
    qa.answer(optional,1,[5]);qa.answer(optional,24,[15]);optional['answers']['P28']={'option_ids':[],'zone_ids':[],'state_code':'omitted','text':None}
    check('P28 enriquecedora admite omisión',not qa.validate_input(optional))
    qa.answer(optional,24,[11]);check('P28 necesaria rechaza omisión',bool(qa.validate_input(optional)))
    cascade=copy.deepcopy(request['snapshot']);qa.answer(cascade,16,[4]);qa.answer(cascade,17,[3]);qa.answer(cascade,18,[1]);check('Cadena P16 P17 P18 válida',not qa.validate_input(cascade))
    qa.answer(cascade,16,[1]);check('Cambio de padre rechaza datos residuales',bool(qa.validate_input(cascade)))
    with tempfile.TemporaryDirectory(prefix='motor_corrupto_') as temp:
        isolated=Path(temp)
        shutil.copyfile(ROOT/'ejecutar.py',isolated/'ejecutar.py')
        (isolated/'motor').mkdir()
        (isolated/'motor/composer.py').write_text("raise RuntimeError('PRIVATE_TEST_SENTINEL')\n",encoding='utf-8')
        p=subprocess.run([sys.executable,str(isolated/'ejecutar.py')],input=json.dumps(request),text=True,encoding='utf-8',capture_output=True,timeout=30)
        check('Fallo de carga distingue error del motor',p.returncode==3 and not p.stdout.strip() and json.loads(p.stderr)['code']=='ENGINE_LOAD_ERROR')
        check('Fallo de carga no expone excepciones', 'PRIVATE_TEST_SENTINEL' not in p.stderr and 'Traceback' not in p.stderr)
    print(json.dumps({'status':'PACKAGE_CHECKS_PASS','checks':len(checks),'passed_checks':checks,
                      'production_delivery':False,'scope':'Motor adaptado y contrato de entrada V4; no aprobación editorial ni prueba de la maqueta.'},ensure_ascii=False,indent=2))

if __name__=='__main__':
    if not sys.flags.utf8_mode:
        raise SystemExit(subprocess.run([sys.executable,'-X','utf8',str(Path(__file__).resolve()),*sys.argv[1:]]).returncode)
    sys.stdout.reconfigure(encoding='utf-8');sys.stderr.reconfigure(encoding='utf-8')
    try:main()
    except RuntimeError as exc:
        print(json.dumps({'status':'PACKAGE_CHECKS_FAIL','failed_check':str(exc),'production_delivery':False}),file=sys.stderr)
        raise SystemExit(1)
    except Exception:
        print(json.dumps({'status':'PACKAGE_CHECKS_FAIL','production_delivery':False}),file=sys.stderr)
        raise SystemExit(1)
