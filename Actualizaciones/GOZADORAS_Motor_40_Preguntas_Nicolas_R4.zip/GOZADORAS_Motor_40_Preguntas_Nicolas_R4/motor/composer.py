"""Composition contract 12 adapted to all V4 input records; editorial review pending.

Snapshot -> closed Object -> name/summary. No case_id dispatch and no access to
expected paragraphs. Semantic coverage is partial. Templates are clause-level
editorial candidates; this is not an LLM renderer or the deployed application.
"""
import copy
import hashlib
import json
import re
from collections import Counter
from qa import ROOT, OPTIONS, evidence, expression_match, guards, oid, validate_input, request_error

COMPOSITION_CATALOG = json.loads((ROOT / 'composition_catalog.json').read_text(encoding='utf-8'))

VERSION = 'composition-controlled-12-v4-compatible-r4'
SNAPSHOT_SCHEMA = 'mapa-experiencia-40-v4-r4'
INSTRUMENT_FINGERPRINT = hashlib.sha256(
    json.dumps(json.loads((ROOT.parent / 'contrato_instrumento_v4.json').read_text(encoding='utf-8')), ensure_ascii=False, sort_keys=True).encode('utf-8')
).hexdigest()

# Explicit partner-referent answers need a referent before contextual expansion.
# A No preview preserves their records and guards, without relabeling them.
PARTNER_REFERENT_FACTS = ('affective', 'erotic', 'reciprocity', 'partner_response', 'feeling_desired', 'initiative_response')

# Observable anchors required by each selected relationship. These are necessary
# structural checks; their presence does not prove the prose expresses it well.
RELATION_FACT_KEYS = {
    'R_EXPLORATION_WELL': ['well'],
    'R_RESPONSIVE': ['desire_before', 'desire_during'],
    'R_TIME': ['time'], 'R_MORE_DESIRE': ['pleasure'],
    'R_RECIPROCITY_GAP': ['reciprocity'],
    'R_CLOSENESS_SPLIT': ['affective', 'erotic'],
    'R_EXPRESSION_RESPECT': ['limits', 'partner_response'],
    'R_BODY_MIXED': ['body_condition', 'body_details', 'pleasure'],
    'R_BODY_WISH': ['body_registration', 'body_comfort'],
    'R_RECOVER_EXPLORE': ['miss', 'exploration_style'],
    'R_NO_CHANGE_GAP': ['no_change', 'gap', 'pleasure'],
    'R_CHOICE_RESOURCE': ['no_change', 'agency'],
    'R_CURIOUS_UNCLEAR': ['change_unknown'],
    'R_UNCERTAINTY_SCOPES': ['body_sensations_uncertain', 'agency', 'gap'],
    'R_RECENT_ABSENCE': ['pleasure'],
    'R_INTERNAL_FREEDOM': ['internal_permission'],
    'R_MATERIAL_PRIVACY': ['material_privacy'],
    'R_EXPANSION_RESOURCES': ['desire_present', 'pleasure', 'limits', 'agency'],
    'R_CARE_DESIRED': ['limits', 'partner_response', 'safety'],
    'R_DESIRE_VARIABLE_PLEASURE': ['desire_before', 'pleasure'],
    'R_LOCAL_BODY_GAP_UNCERTAINTY': ['body_sensations_uncertain', 'gap'],
    'R_CARE_PRESENT': ['limits', 'partner_response', 'safety'],
    'R_BOUNDED_PRESENT': [],
    'R_ENCOUNTER_PAUSE': ['encounter_response'],
    'R_ENCOUNTER_RESPONSE': ['encounter_response'],
    'R_AUTONOMY_SOURCES': ['agency', 'autonomy_sources'],
    'R_ORGASM_SCOPE': ['orgasm_experience'],
    'R_FEELING_DESIRED': ['feeling_desired'],
    'R_BODY_CONDITION_PRESENT': ['body_condition', 'body_details'],
    'R_DAILY_CONDITIONS': ['daily_impact', 'daily_burdens'],
    'R_EXPLORE_FAMILIAR': ['curiosity', 'exploration_style'],
    'R_EXPLORATION_MISMATCH': ['curiosity', 'exploration_style'],
    'R_INTERNAL_NO_DIFFICULTY': ['internal_permission'],
    'R_AUTONOMY_UNSPECIFIED': ['agency', 'autonomy_detail_state'],
}

def join(items):
    items = [x for x in items if x]
    if len(items) < 2:
        return ''.join(items)
    return ', '.join(items[:-1]) + ' y ' + items[-1]

def sentence(text):
    return text[:1].upper() + text[1:].rstrip(' .') + '.' if text else ''

WISHES = {
    1: 'sentir más ganas', 2: 'sentir más placer', 3: 'disfrutar más los encuentros',
    4: 'explorar tu orgasmo', 5: 'reconocer mejor lo que pasa en tu cuerpo',
    6: 'sentirte más cómoda con tu cuerpo', 7: 'sentirte más deseada',
    8: 'encontrar una forma de cercanía que te haga sentido',
    9: 'que tu placer importe tanto como el de tu pareja',
    10: 'expresar mejor lo que quieres y lo que no quieres',
    11: 'experimentar cosas nuevas', 12: 'tener más tiempo o espacio para tu vida erótica',
    13: 'sentirte más libre para expresar o vivir lo que deseas', 14: 'recuperar algo que antes tenías',
}
VALUES = {1: 'sentir placer', 2: 'sentir deseo', 3: 'fantasear o imaginar',
          4: 'sentirte conectada con tu cuerpo', 5: 'conocerte más',
          6: 'descubrir lo que te gusta', 7: 'expresar lo que quieres',
          8: 'explorar nuevas posibilidades', 9: 'vivir tu erotismo a tu manera',
          10: 'compartir intimidad', 11: 'sentirte deseada', 12: 'jugar y divertirte',
          13: 'sentir conexión profunda'}

# Closed clauses derived from exact options. Privacy creates no content clause.
CLAUSES = {
    'value_scope': (22, {
        15: 'hoy no destacas algo en particular como lo más valioso de tu vida erótica',
        16: 'no te habías detenido a pensar en qué valoras de tu vida erótica'}),
    'autonomy_detail_state': (33, {
        6: 'no identificas una restricción de autonomía entre las opciones de tiempo, dinero, libertad de decisión o dependencia de tu pareja',
        7: 'no habías considerado qué aspectos de tu autonomía podrían limitar tu vida erótica'}),
    'exploration_style': (28, {
        1: 'te interesa probar cosas nuevas',
        2: 'te interesa hacer más algunas cosas que ya haces',
        4: 'no te interesa probar cosas nuevas ni hacer más algunas cosas que ya haces',
        5: 'aún no sabes si te interesa probar algo nuevo o hacer más lo que ya haces'}),
    'daily_impact': (19, {
        1: 'tu vida cotidiana favorece mucho tu vida erótica',
        2: 'tu vida cotidiana favorece algo tu vida erótica',
        3: 'tu vida cotidiana a veces favorece tu vida erótica y a veces la dificulta',
        4: 'tu vida cotidiana dificulta algo tu vida erótica',
        5: 'tu vida cotidiana dificulta mucho tu vida erótica',
        6: 'tu vida cotidiana no influye en tu vida erótica',
        7: 'todavía no tienes claro cómo influye tu vida cotidiana en tu vida erótica'}),
    'orgasm_experience': (25, {
        1: 'llegas al orgasmo con facilidad y estás bien así',
        2: 'llegas al orgasmo y te cuesta más que antes',
        3: 'llegas al orgasmo algunas veces y te gustaría llegar más',
        4: 'rara vez llegas al orgasmo y eso te importa',
        5: 'rara vez llegas al orgasmo y no te preocupa',
        6: 'no llegas al orgasmo', 7: 'nunca has tenido un orgasmo',
        8: 'hace tanto que no llegas al orgasmo que no recuerdas cuándo fue',
        9: 'el orgasmo no es importante para ti',
        10: 'todavía no tienes clara tu experiencia con el orgasmo'}),
    'feeling_desired': (30, {
        1: 'te sientes muy deseada por tu pareja',
        2: 'te sientes bastante deseada por tu pareja',
        3: 'te sientes más o menos deseada por tu pareja',
        4: 'te sientes poco deseada por tu pareja',
        5: 'no te sientes deseada por tu pareja',
        6: 'todavía no tienes claro cuánto te sientes deseada por tu pareja',
        7: 'sentirte deseada por tu pareja no es algo que te importe'}),
    'initiative_response': (31, {
        1: 'cuando tú buscas un encuentro, tu pareja casi siempre tiene ganas',
        2: 'cuando tú buscas un encuentro, tu pareja muchas veces tiene ganas',
        3: 'la respuesta a tu iniciativa depende de la situación',
        4: 'cuando tú buscas un encuentro, tu pareja pocas veces tiene ganas',
        5: 'cuando tú buscas un encuentro, tu pareja casi nunca tiene ganas',
        6: 'no sueles tomar la iniciativa', 7: 'nunca tomas la iniciativa',
        8: 'todavía no tienes claro qué sucede cuando tomas la iniciativa'}),
    'gap': (2, {1: 'tu vida erótica está muy cerca de cómo te gustaría vivirla',
               2: 'tu vida erótica está bastante cerca de cómo te gustaría vivirla',
               3: 'tu vida erótica no está ni muy cerca ni muy lejos de cómo te gustaría vivirla',
               4: 'reconoces una distancia importante respecto de la vida erótica que te gustaría tener',
               5: 'sientes tu vida erótica muy lejos de cómo te gustaría vivirla',
               6: 'te sientes bien con tu vida erótica tal como está',
               7: 'la cercanía entre lo que vives hoy y la vida erótica que te gustaría tener también es una pregunta abierta'}),
    'body_condition': (6, {1: 'hay cambios o molestias en tu cuerpo o bienestar que afectan tu vida erótica',
                          2: 'consideras posible que algún cambio o molestia en tu cuerpo o bienestar esté afectando tu vida erótica'}),
    'desire_before': (8, {1: 'las ganas aparecen muy seguido antes de empezar',
                         2: 'las ganas aparecen seguido antes de empezar',
                         3: 'las ganas aparecen a veces antes de empezar',
                         4: 'las ganas rara vez aparecen antes de empezar',
                         5: 'las ganas no aparecen antes de empezar',
                         6: 'no has tenido acercamientos últimamente para situar cuándo aparecen las ganas antes de empezar'}),
    'desire_during': (9, {1: 'casi siempre aumentan durante una oportunidad que eliges darte',
                         2: 'muchas veces aumentan durante una oportunidad que eliges darte',
                         3: 'a veces aumentan durante una oportunidad que eliges darte',
                         4: 'rara vez aumentan durante una oportunidad que eliges darte',
                         5: 'no aumentan durante una oportunidad que eliges darte',
                         6: 'no te ha pasado esa experiencia de darte una oportunidad al principio sin ganas',
                         7: 'no sueles darte esa oportunidad cuando al principio no tienes ganas'}),
    'pleasure': (10, {1: 'disfrutas mucho tus encuentros eróticos', 2: 'disfrutas bastante tus encuentros eróticos',
                     3: 'encuentras algo de disfrute en tus encuentros eróticos',
                     4: 'encuentras poco disfrute en tus encuentros eróticos',
                     5: 'no encuentras disfrute en tus encuentros eróticos',
                     6: 'el disfrute varía en tus encuentros eróticos',
                     7: 'todavía no tienes claro cuánto disfrutas tus encuentros eróticos',
                     8: 'no has tenido encuentros eróticos recientemente'}),
    'affective': (13, {1: 'te sientes muy cerca de tu pareja afectivamente',
                      2: 'sientes bastante cercanía afectiva con tu pareja',
                      3: 'afectivamente no te sientes ni cerca ni distante de tu pareja',
                      4: 'te sientes bastante distante de tu pareja afectivamente',
                      5: 'te sientes muy distante de tu pareja afectivamente',
                      6: 'la cercanía afectiva con tu pareja varía',
                      7: 'la cercanía afectiva con tu pareja no está clara para ti',
                      8: 'la cercanía afectiva con tu pareja no es algo que te importe'}),
    'erotic': (14, {1: 'te sientes muy cerca de tu pareja eróticamente',
                   2: 'sientes bastante cercanía erótica con tu pareja',
                   3: 'eróticamente no te sientes ni cerca ni distante de tu pareja',
                   4: 'te sientes bastante distante de tu pareja eróticamente',
                   5: 'te sientes muy distante de tu pareja eróticamente',
                   6: 'la cercanía erótica con tu pareja varía',
                      7: 'la cercanía erótica con tu pareja no está clara',
                      8: 'la cercanía erótica con tu pareja no es algo que te importe'}),
    'reciprocity': (15, {1: 'siempre o casi siempre percibes que tu placer importa tanto como el de tu pareja',
                        2: 'la mayor parte del tiempo percibes que tu placer importa tanto como el de tu pareja',
                        3: 'a veces percibes que tu placer importa tanto como el de tu pareja',
                        4: 'pocas veces percibes que tu placer importa tanto como el de tu pareja',
                        5: 'no percibes que tu placer importe tanto como el de tu pareja',
                        6: 'esa reciprocidad varía en tus encuentros',
                        8: 'todavía no tienes clara esa reciprocidad en tus encuentros'}),
    'limits': (16, {1: 'te resulta fácil expresar lo que no quieres o cuándo quieres parar',
                   2: 'en general puedes expresar lo que no quieres o cuándo quieres parar',
                   3: 'la posibilidad de expresar lo que no quieres o cuándo quieres parar depende de la situación',
                   4: 'te cuesta expresar lo que no quieres o cuándo quieres parar',
                   5: 'sientes que no puedes decir que no o parar',
                   6: 'no se ha dado esa situación de expresar lo que no quieres o cuándo quieres parar',
                   7: 'todavía no tienes claro qué tan posible te resulta expresar lo que no quieres o cuándo quieres parar'}),
    'partner_response': (17, {1: 'tu pareja lo respeta sin problema cuando lo expresas',
                             2: 'tu pareja generalmente lo respeta cuando lo expresas',
                             3: 'tu pareja a veces insiste o se molesta',
                             4: 'tu pareja muchas veces insiste o se molesta',
                             5: 'la respuesta de tu pareja depende de la situación',
                             6: 'no se ha dado esa situación con tu pareja',
                             7: 'todavía no tienes clara la respuesta de tu pareja'}),
    'safety': (18, {1: 'dices que te sientes segura para decir que no o parar',
                   2: 'dices que generalmente te sientes segura para decir que no o parar',
                   3: 'la seguridad que sientes para decir que no o parar depende de la situación',
                   4: 'no te sientes segura para decir que no o parar',
                   5: 'todavía no tienes claro si te sientes segura para decir que no o parar'}),
    'agency': (21, {1: 'reconoces mucho margen para decidir sobre tu vida erótica',
                   2: 'reconoces margen para decidir sobre tu vida erótica',
                   3: 'reconoces algo de margen para decidir sobre tu vida erótica',
                   4: 'reconoces poco margen para decidir sobre tu vida erótica',
                   5: 'reconoces muy poco margen para decidir sobre tu vida erótica',
                   6: 'todavía no tienes claro cuánto puedes decidir sobre tu propia vida erótica'}),
    'body_registration': (26, {1: 'en tu vida erótica, te resulta muy fácil reconocer lo que pasa en tu cuerpo',
                              2: 'en tu vida erótica, te resulta bastante fácil reconocer lo que pasa en tu cuerpo',
                              3: 'en tu vida erótica, a veces reconoces lo que pasa en tu cuerpo y a veces no',
                              4: 'en tu vida erótica, te cuesta reconocer lo que pasa en tu cuerpo',
                              5: 'en tu vida erótica, te cuesta mucho reconocer lo que pasa en tu cuerpo',
                              6: 'todavía no tienes claro qué tan fácil te resulta reconocer lo que pasa en tu cuerpo en tu vida erótica'}),
    'body_comfort': (27, {1: 'te sientes muy cómoda con tu cuerpo', 2: 'te sientes bastante cómoda con tu cuerpo',
                         3: 'te sientes más o menos cómoda con tu cuerpo', 4: 'te sientes poco cómoda con tu cuerpo',
                         5: 'no te sientes cómoda con tu cuerpo', 6: 'todavía no tienes clara esa comodidad con tu cuerpo'}),
    'internal_permission': (29, {1: 'hay intereses que te cuesta reconocer incluso para ti misma',
                               2: 'a veces hay intereses que te cuesta reconocer incluso para ti misma',
                               3: 'no señalas intereses que te cueste reconocer para ti misma',
                               4: 'todavía no tienes claro si te cuesta reconocer algunos intereses incluso para ti misma'}),
    'material_privacy': (32, {1: 'los espacios donde vives te ofrecen completamente la privacidad que necesitas',
                            2: 'los espacios donde vives te ofrecen la privacidad que necesitas la mayor parte del tiempo',
                            3: 'los espacios donde vives solo a veces te ofrecen la privacidad que necesitas',
                            4: 'los espacios donde vives pocas veces te ofrecen la privacidad que necesitas',
                            5: 'los espacios donde vives no te ofrecen la privacidad que necesitas',
                            6: 'la privacidad que encuentras en los espacios donde vives depende de la situación',
                            7: 'todavía no tienes clara la privacidad que te ofrecen los espacios donde vives'}),
}

def compile_object(snapshot, *, applicability_preview=False):
    errors = validate_input(snapshot)
    if errors:
        raise ValueError(errors)
    partner_context = snapshot['context'].get('current_partner')
    if partner_context not in ('yes', 'no', 'prefer_not_to_answer'):
        raise ValueError('Unknown current_partner context code')
    # Access outside the target population does not require another instrument.
    # Existing question wording, required answers and branches still apply.
    no_partner = partner_context == 'no'
    # Deliberately do not copy case_id, expected paragraphs, or session metadata.
    data = copy.deepcopy(snapshot['answers'])
    obj = {'version': VERSION, 'facts': {}, 'values': [], 'desired_changes': [],
           'constraints': [], 'relations': [], 'literal_text': {}, 'flags': {}}
    # Retain every structured answer even when its scope is not represented
    # by the selected reading. Omission from prose never deletes evidence.
    obj['response_records'] = copy.deepcopy(data)
    obj['applicability'] = {'reported_context': partner_context,
        'mode': 'ACCESS_OUTSIDE_TARGET_SCOPE' if no_partner else 'DIRECT_RESPONSES',
        'unresolved_reference_answers': {},
        'reported_encounter_answers': {},
        'note': 'CTX privacy neither negates nor confirms a relationship; direct P13-P18 answers keep their own evidence'}
    def fact(key, text, ids, category='observation'):
        obj['facts'][key] = {'clause': text, 'evidence_ids': sorted(ids), 'category': category}
    def selected(q, *ns):
        return sorted(set(data[f'P{q:02d}']['option_ids']) & {oid(q, n) for n in ns})
    def present(q, *ns):
        return bool(selected(q, *ns))
    for key, (q, phrases) in CLAUSES.items():
        if no_partner and key in PARTNER_REFERENT_FACTS:
            if data[f'P{q:02d}']['state_code'] not in ('not_shown', 'omitted'):
                obj['applicability']['unresolved_reference_answers'][f'P{q:02d}'] = copy.deepcopy(data[f'P{q:02d}'])
            continue
        for n, clause in phrases.items():
            if present(q, n):
                fact(key, clause, [oid(q, n)])
    for n, clause in VALUES.items():
        if present(22, n):
            obj['values'].append({'clause': clause, 'evidence_ids': [oid(22, n)]})
    for n, clause in WISHES.items():
        if present(24, n):
            if no_partner and n == 9:
                clause = 'vivir reciprocidad en el placer'
            obj['desired_changes'].append({'clause': clause, 'evidence_ids': [oid(24, n)]})
    if present(8,6):
        obj['facts']['desire_before']['category']='not_observed'
    if data['P11']['zone_ids']:
        fact('body_sensations', 'reconoces sensaciones agradables en algunas zonas de tu cuerpo', data['P11']['zone_ids'], 'present_resource')
    elif present(11, 2):
        fact('body_sensations_uncertain', 'siguen abiertas las preguntas sobre qué sensaciones agradables identificas en tu cuerpo', [oid(11, 2)], 'local_uncertainty')
    elif present(11, 1):
        fact('body_sensations_not_identified', 'no identificas sensaciones agradables en ninguna zona de tu cuerpo en este momento', [oid(11, 1)], 'current_report')
    if present(6, 3):
        fact('body_condition_absent', 'no señalas cambios o molestias en tu cuerpo o bienestar que estén afectando tu vida erótica', [oid(6, 3)], 'current_report')
    if present(15, 7) and not no_partner:
        fact('reciprocity_not_observed', 'no has tenido encuentros eróticos últimamente para situar esa reciprocidad', [oid(15, 7)], 'not_observed')
    if present(1, 1):
        fact('well', 'hoy te sientes bien con tu vida erótica', [oid(1, 1)], 'state')
    if present(1, 2):
        fact('miss', 'extrañas algo de tu vida erótica de antes', [oid(1, 2)], 'state')
    if present(1, 3):
        fact('change_unclear', 'reconoces que algo cambió y todavía no entiendes bien qué está pasando', [oid(1, 3)], 'state')
    if present(1, 4):
        fact('dissatisfied', 'no te gusta cómo está tu vida erótica y quisieras hacer algo', [oid(1, 4)], 'state')
    if present(1, 6):
        fact('disconnected', 'hoy te sientes desconectada y todavía no sabes bien qué quieres', [oid(1, 6)], 'state')
    if present(24, 15):
        fact('no_change', 'hoy no quieres mover nada', [oid(24, 15)], 'desired_change_state')
    if present(24, 17):
        fact('change_unknown', 'todavía no sabes qué quisieras mover de tu vida erótica', [oid(24, 17)], 'desired_change_state')
    if present(12, 6):
        fact('retry', 'tienes ganas de volver a intentarlo', [oid(12, 6)], 'present_resource')
    response_clauses = {
        1: 'te frustras o desanimas',
        2: 'te preocupa que vuelva a pasar',
        3: 'te gustaría volver a intentarlo y te cuesta',
        4: 'prefieres evitar otro encuentro para que no vuelva a pasar',
        5: 'no quieres tener otro encuentro erótico por ahora',
        6: 'tienes ganas de volver a intentarlo',
        7: 'no te ha pasado esa experiencia',
        8: 'todavía no tienes claro qué te pasa después'}
    responses = selected(12, *response_clauses)
    if responses:
        fact('encounter_response', join([response_clauses[int(i[-2:])] for i in responses]), responses, 'encounter_response')
    autonomy_clauses = {
        1: 'tu tiempo', 2: 'el dinero',
        3: 'tu libertad para tomar algunas decisiones',
        4: 'depender de tu pareja para algunas decisiones o recursos'}
    restrictions = [i for i in selected(33, *autonomy_clauses) if not (no_partner and i == oid(33, 4))]
    if no_partner and present(33, 4):
        obj['applicability']['unresolved_reference_answers']['P33'] = copy.deepcopy(data['P33'])
    if restrictions:
        fact('autonomy_sources', join([autonomy_clauses[int(i[-2:])] for i in restrictions]) + ' aparece como una restricción de tu autonomía' if len(restrictions) == 1 else join([autonomy_clauses[int(i[-2:])] for i in restrictions]) + ' aparecen como restricciones de tu autonomía', restrictions, 'signal_constraint')
    if no_partner and present(33, 6):
        fact('autonomy_detail_state', 'no identificas una restricción de tiempo, dinero o libertad de decisión entre las opciones ofrecidas', [oid(33, 6)], 'local_report')
    if present(28, 3):
        fact('exploration_style', 'te interesa tanto probar algo nuevo como profundizar en algo que ya existe', [oid(28, 3)], 'declared_interest')
    curiosity_sources = selected(1, 5) + selected(22, 6, 8) + selected(24, 11)
    if curiosity_sources:
        fact('curiosity', 'tu interés por explorar está presente', curiosity_sources, 'declared_interest')
    desire_sources = selected(8, 1, 2, 3) + selected(9, 1, 2, 3)
    if desire_sources:
        fact('desire_present', 'el deseo está presente', desire_sources, 'present_resource')
    if present(20, 7):
        fact('time', 'la falta de tiempo es una dificultad concreta en tu vida erótica cotidiana', [oid(20, 7)], 'daily_condition')
    if present(20, 9):
        fact('privacy_report', 'señalas la falta de privacidad entre lo que más pesa en lo cotidiano', [oid(20, 9)], 'daily_condition')
    body_labels = {1:'dolor', 2:'lubricación', 3:'molestias genitales', 4:'molestias urinarias',
                   5:'molestias musculoesqueléticas', 6:'cambios de sensibilidad', 7:'energía',
                   8:'sueño', 9:'bochornos', 10:'cansancio físico', 11:'ánimo', 12:'ansiedad',
                   13:'cansancio mental'}
    body_ids = selected(7, *body_labels)
    if body_ids:
        detail_intro = ('entre lo que consideras que podría afectar tu vida erótica, señalas '
                        if present(6, 2) else 'entre lo que más afecta hoy tu vida erótica, señalas ')
        fact('body_details', detail_intro + join([body_labels[int(i[-2:])] for i in body_ids]), body_ids, 'body_condition_details')
    burden_labels = {1:'el trabajo', 2:'el dinero', 3:'la carga mental', 4:'los cuidados de otras personas',
                     5:'las responsabilidades del hogar', 6:'otras responsabilidades',
                     7:'la falta de tiempo', 8:'la falta de espacio', 9:'la falta de privacidad'}
    burden_ids = selected(20, *burden_labels)
    if burden_ids:
        fact('daily_burdens', 'entre lo que más pesa hoy, señalas ' + join([burden_labels[int(i[-2:])] for i in burden_ids]), burden_ids, 'daily_condition_details')
    for q, a in data.items():
        if a['state_code'] == 'prefer_not_to_answer':
            obj['constraints'].append({'scope': q, 'kind': 'privacy', 'evidence_ids': a['option_ids']})
        if a['state_code'] in ('dont_know', 'not_clear'):
            obj['constraints'].append({'scope': q, 'kind': 'uncertainty', 'evidence_ids': a['option_ids']})
        if a['text']:
            obj['literal_text'][q] = a['text']
    obj['flags'] = {
        'care': present(16, 5) or (not no_partner and present(17, 3, 4)) or present(18, 4),
        'limits_cannot': present(16, 5), 'partner_insists': not no_partner and present(17, 3, 4),
        'safety_no': present(18, 4), 'low_agency': present(21, 4, 5),
        'positive_agency': present(21, 1, 2), 'positive_limits': present(16, 1, 2),
        'limits_difficulty': present(16, 4, 5),
        'respect_response': present(17, 1, 2), 'positive_safety': present(18, 1, 2),
        'body_resource_present': bool(data['P11']['zone_ids']) or present(10, 1, 2),
        'confirmed_body_condition': present(6, 1),
        'body_focus': present(24, 5, 6), 'wants_freedom': present(24, 13),
        'wants_exploration': present(24, 11) or present(1, 5),
        'no_change': present(24, 15), 'change_unknown': present(24, 17),
        'responsive': present(8, 4, 5) and present(9, 1, 2),
        'closeness_split': not no_partner and present(13, 1, 2) and present(14, 4, 5),
        'material_privacy_limited': present(32, 3, 4, 5, 6, 7) and present(20, 9),
        'internal_difficulty': present(29, 1, 2),
        'agency_unknown': present(21, 6), 'gap_unknown': present(2, 7),
        'positive_pleasure': present(10, 1, 2),
        'wants_reciprocity': present(24, 9), 'wants_expression': present(24, 10),
        'wants_more_desire': present(24, 1),
        'values_pleasure_play': present(22, 1) and present(22, 12),
        'far_gap': present(2, 4, 5),
        'positive_affective': not no_partner and present(13, 1, 2),
        'positive_erotic': not no_partner and present(14, 1, 2),
        'desire_present': present(8, 1, 2, 3) or present(9, 1, 2, 3),
        'no_partner_candidate': no_partner,
    }
    resource_sources = {
        'pleasure': (10, (1, 2)), 'affective': (13, (1, 2)),
        'erotic': (14, (1, 2)), 'reciprocity': (15, (1, 2)),
        'limits': (16, (1, 2)), 'partner_response': (17, (1, 2)),
        'agency': (21, (1, 2)), 'desire_present': (8, (1, 2, 3)),
        'retry': (12, (6,)), 'body_registration': (26, (1, 2)),
        'body_comfort': (27, (1, 2)),
    }
    obj['present_resources'] = []
    for key, (q, ns) in resource_sources.items():
        if key in obj['facts'] and (present(q, *ns) or (key == 'desire_present' and desire_sources)):
            obj['present_resources'].append({'kind': key, 'evidence_ids': obj['facts'][key]['evidence_ids']})
    if 'body_sensations' in obj['facts']:
        obj['present_resources'].append({'kind': 'body_sensations', 'evidence_ids': obj['facts']['body_sensations']['evidence_ids']})
    if present(24,17):
        obj['constraints'].append({'scope':'P24','kind':'uncertainty','evidence_ids':['P24_O17']})
    obj['uncertainty'] = [copy.deepcopy(x) for x in obj['constraints'] if x['kind'] == 'uncertainty']
    obj['option_treatment'] = {}
    literal_fields = {'P01_O07':'P34', 'P03_O14':'P35', 'P07_O14':'P38',
                      'P20_O10':'P39', 'P22_O14':'P36', 'P24_O16':'P37', 'P33_O05':'P40'}
    content_ids = {i for v in obj['facts'].values() for i in v['evidence_ids']}
    content_ids.update(i for v in obj['values'] + obj['desired_changes'] for i in v['evidence_ids'])
    private_ids = {i for c in obj['constraints'] if c['kind']=='privacy' for i in c['evidence_ids']}
    uncertain_ids = {i for c in obj['constraints'] if c['kind']=='uncertainty' for i in c['evidence_ids']}
    # Every selected option has an explicit role. Context/history is retained
    # without promoting it to a cause; literal branches never supply inferred
    # desires, diagnoses or constraints from their text.
    for q, record in data.items():
        for i in record['option_ids']:
            if i in private_ids:
                role = 'PRIVACY_ONLY'
            elif i in content_ids:
                role = 'CONTENT_MAPPING'
            elif i in literal_fields:
                role = 'LITERAL_ELICITATION_ONLY'
            elif i in uncertain_ids:
                role = 'UNCERTAINTY_ONLY'
            elif q in ('P03', 'P04', 'P03_MICRO'):
                role = 'CONTEXT_HISTORY_ONLY'
            elif q in obj['applicability']['unresolved_reference_answers']:
                role = 'UNRESOLVED_PARTNER_REFERENT'
            else:
                role = 'UNDEFINED_OPTION_TREATMENT'
            obj['option_treatment'][i] = {'role': role, 'source_question': q}
            if i in literal_fields:
                obj['option_treatment'][i]['literal_field'] = literal_fields[i]
    obj['guards'] = guards(snapshot, COMPOSITION_CATALOG)
    obj['connector_permissions'] = [
        dict(r, evidence_ids=evidence(snapshot, r['when'], COMPOSITION_CATALOG))
        for r in COMPOSITION_CATALOG['connectors']
        if expression_match(snapshot, r['when'], COMPOSITION_CATALOG)
    ]
    obj['reflective_permissions'] = [
        dict(r, evidence_ids=[i for i in evidence(snapshot, r['when'], COMPOSITION_CATALOG)
                              if i not in r.get('activation_only_option_ids', [])])
        for r in COMPOSITION_CATALOG.get('reflective_closings', [])
        if expression_match(snapshot, r['when'], COMPOSITION_CATALOG)
    ]
    obj['surface_permissions'] = [
        dict(r, evidence_ids=[i for i in evidence(snapshot, r['when'], COMPOSITION_CATALOG)
                              if i not in r.get('activation_only_option_ids', [])])
        for r in COMPOSITION_CATALOG.get('surface_rules', [])
        if expression_match(snapshot, r['when'], COMPOSITION_CATALOG)
        and not (no_partner and r.get('partner_required'))
    ]
    obj['applicability']['unresolved_care_guards'] = (
        [g['rule_id'] for g in obj['guards'] if g['rule_id'] == 'G_PARTNER_INSISTS'] if no_partner else [])
    # One executable catalogue, rather than documented rules plus hidden code.
    matched_ids = set()
    for rule in sorted(COMPOSITION_CATALOG['relations'], key=lambda r: (r['rule_id'] == 'R_BOUNDED_PRESENT', r['stable_order'])):
        if no_partner and rule['rule_id'] == 'R_FEELING_DESIRED':
            continue
        if no_partner and rule['rule_id'] in ('R_CLOSENESS_SPLIT', 'R_RECIPROCITY_GAP', 'R_EXPRESSION_RESPECT', 'R_RECENT_ABSENCE'):
            continue
        if no_partner and rule['rule_id'] in ('R_CARE_DESIRED', 'R_CARE_PRESENT') and not obj['flags']['care']:
            # Preserve an unresolved P17 care signal for review. It does not
            # establish a present relationship or present tension in this preview.
            continue
        condition = rule['when']
        if condition.get('unless_rule_active') in matched_ids:
            continue
        active = not obj['relations'] if condition.get('no_relations_active') else expression_match(snapshot, condition, COMPOSITION_CATALOG)
        if not active:
            continue
        ids = (sorted({i for k in rule['evidence_fact_keys'] if k in obj['facts'] for i in obj['facts'][k]['evidence_ids']})
               if 'evidence_fact_keys' in rule else evidence(snapshot, condition, COMPOSITION_CATALOG))
        obj['relations'].append(dict(rule, evidence_trace=ids))
        matched_ids.add(rule['rule_id'])
    return obj

def select_relations(obj):
    remaining = copy.deepcopy(obj['relations']); selected = []; covered = set()
    while remaining and len(selected) < 3:
        remaining.sort(key=lambda r: (r['priority'], -len(set(r['aspects']) - covered), r['stable_order']))
        r = remaining.pop(0); selected.append(r); covered.update(r['aspects'])
    essential_left = sorted([r for r in remaining if r['priority'] == 1], key=lambda r: r['stable_order'])
    exception = None
    if essential_left:
        # Keep all explicitly indispensable relations. Do not drop one just to
        # satisfy an editorial count. Extended drafts always request editorial QA.
        selected += essential_left
        exception = {'reason': 'INDISPENSABLE_DISTINCTION', 'added_rules': [r['rule_id'] for r in essential_left],
                     'evidence_trace': {r['rule_id']: r['evidence_trace'] for r in essential_left}}
    return selected, exception

def render_object(obj):
    facts = obj['facts']; flags = obj['flags']; used = set(); trace = []; emissions = []
    connector_trace = []
    selected, exception = select_relations(obj)
    chosen_ids = {r['rule_id'] for r in selected}
    body_narrative = (flags['body_focus'] and selected and
                      selected[0]['rule_id'] in {'R_BODY_WISH', 'R_BODY_MIXED', 'R_BODY_CONDITION_PRESENT'} and
                      'R_CLOSENESS_SPLIT' not in chosen_ids)
    reflection_trace = []
    synthesis_trace = []
    surface_permissions = {r['rule_id']: r for r in obj.get('surface_permissions', [])
                           if set(r['parent_relations']) & chosen_ids}
    reflective_rule = next((r for r in obj.get('reflective_permissions', [])
                           if set(r['required_relations']) <= chosen_ids
                           and not flags['care']), None)
    desire_space = (flags['responsive'] and 'R_RESPONSIVE' in chosen_ids and 'R_MORE_DESIRE' in chosen_ids
                    and flags['wants_more_desire']
                    and not any(flags[k] for k in ('care', 'body_focus', 'change_unknown', 'closeness_split'))
                    and not (flags['wants_freedom'] and flags['wants_exploration']))
    no_change_synthesis = flags['no_change'] and flags['positive_pleasure'] and flags['far_gap'] and flags['closeness_split']
    def connect(connector_id, text, fallback='; '):
        permission = next((r for r in obj['connector_permissions'] if r['connector_id'] == connector_id), None)
        allowed = bool(permission) and (not permission.get('required_relation') or permission['required_relation'] in chosen_ids)
        allowed = allowed and bool(set(permission.get('parent_relations', [])) & chosen_ids)
        if not allowed:
            return fallback
        connector_trace.append({'connector_id': connector_id, 'phrase': text.strip(' ,;'),
                                'authorized': allowed,
                                'parent_relations': sorted(set(permission['parent_relations']) & chosen_ids),
                                'evidence_ids': permission['evidence_ids'] if permission else []})
        return text
    def clause(key):
        if key not in facts:
            return ''
        wording = facts[key]['clause']
        if key == 'body_condition' and 'body_details' in facts and chosen_ids & {'R_BODY_MIXED', 'R_BODY_CONDITION_PRESENT'}:
            detail = facts['body_details']['clause'].split('señalas ', 1)[-1]
            detail_text = '(' + detail + ')'
            wording += ' ' + detail_text
            used.add('body_details')
            emissions.append({'text': detail_text, 'claims': [{'claim': 'body_details', 'evidence_ids': facts['body_details']['evidence_ids']}]})
        if key == 'body_registration':
            wording = wording.removeprefix('en tu vida erótica, ').removesuffix(' en tu vida erótica')
        used.add(key)
        trace.append({'claim': key, 'evidence_ids': facts[key]['evidence_ids']})
        emissions.append({'text': wording, 'claims': [{'claim': key, 'evidence_ids': facts[key]['evidence_ids']}]})
        return wording
    def phrases(items):
        for item in items:
            trace.append({'claim': item['clause'], 'evidence_ids': item['evidence_ids']})
            emissions.append({'text': item['clause'], 'claims': [{'claim': item['clause'], 'evidence_ids': item['evidence_ids']}]})
        return join([x['clause'] for x in items])
    def grounded(keys, text):
        for key in keys:
            clause(key)
        if text:
            emissions.append({'text': text.strip(' ,;'), 'claims': [{'claim': k, 'evidence_ids': facts[k]['evidence_ids']} for k in keys if k in facts]})
        return text
    def synthesis(rule_id, keys, text):
        permission = surface_permissions.get(rule_id)
        if not permission:
            return ''
        synthesis_trace.append({'rule_id': rule_id, 'type': permission['type'],
                                'parent_relations': sorted(set(permission['parent_relations']) & chosen_ids),
                                'evidence_ids': permission['evidence_ids']})
        return grounded(keys, text)
    def experience():
        p, r = clause('pleasure'), clause('reciprocity')
        if (oid(10, 7) in facts.get('pleasure', {}).get('evidence_ids', [])
                and oid(15, 8) in facts.get('reciprocity', {}).get('evidence_ids', [])):
            return grounded(['pleasure', 'reciprocity'],
                            'el disfrute y la reciprocidad en tus encuentros aún no están claros')
        if p and r and 'S_PLEASURE_RECIPROCITY_DISTINCT' in surface_permissions:
            return synthesis('S_PLEASURE_RECIPROCITY_DISTINCT', ['pleasure', 'reciprocity'],
                             'el disfrute y la reciprocidad tienen matices distintos: ' + join([p, r]))
        return join([p, r])
    def closeness():
        if flags['closeness_split']:
            return synthesis('S_CLOSENESS_DISTINCT', ['affective', 'erotic'],
                             'la cercanía afectiva con tu pareja coexiste con una distancia erótica') or grounded(['affective', 'erotic'], 'la cercanía afectiva con tu pareja aparece junto a una distancia erótica')
        if flags['positive_affective'] and flags['positive_erotic']:
            return grounded(['affective', 'erotic'], 'sientes cercanía con tu pareja tanto en lo afectivo como en lo erótico')
        # Equal answers can share a subject without erasing either source.
        # Different answers retain their own clauses and degrees.
        same_degree = {
            3: 'no te sientes ni cerca ni distante de tu pareja, tanto en lo afectivo como en lo erótico',
            4: 'te sientes bastante distante de tu pareja, tanto en lo afectivo como en lo erótico',
            5: 'te sientes muy distante de tu pareja, tanto en lo afectivo como en lo erótico',
            6: 'la cercanía con tu pareja varía, tanto en lo afectivo como en lo erótico',
            7: 'todavía no tienes clara la cercanía con tu pareja, ni en lo afectivo ni en lo erótico',
        }
        for degree, text in same_degree.items():
            if (oid(13, degree) in facts.get('affective', {}).get('evidence_ids', [])
                    and oid(14, degree) in facts.get('erotic', {}).get('evidence_ids', [])):
                return grounded(['affective', 'erotic'], text)
        a, e = clause('affective'), clause('erotic')
        return a + ', y ' + e if a and e else a or e
    def responsive_pair():
        return clause('desire_before') + connect('C_RESPONSIVE_CONTRAST', ', pero ') + clause('desire_during')
    wishes = phrases(obj['desired_changes'])
    if wishes:
        opening = 'quieres ' + wishes
        if 'well' in facts:
            opening += grounded(['well'], ', desde una vida erótica con la que hoy te sientes bien')
        if flags['wants_freedom'] and flags['wants_exploration'] and flags['positive_pleasure'] and flags['desire_present']:
            opening = 'quieres ' + wishes + grounded(['desire_present', 'pleasure'], ', en un momento en que el deseo y el disfrute están presentes')
        if flags['wants_exploration'] and flags['values_pleasure_play']:
            value_text = 'el placer y el juego tienen un lugar importante para ti'
            emissions.append({'text': value_text, 'claims': [{'claim': 'pleasure_play_values', 'evidence_ids': ['P22_O01', 'P22_O12']}]})
            opening += '; ' + value_text
        if desire_space and 'well' in facts:
            opening = 'quieres ' + wishes + grounded(['well'], ', en un momento en que te sientes bien con tu vida erótica')
        if desire_space and 'pleasure' in facts:
            opening += (' y ' if 'well' in facts else '; ') + clause('pleasure')
        if 'R_RECOVER_EXPLORE' in chosen_ids and flags['body_focus'] and flags['wants_exploration']:
            opening += grounded(['exploration_style'], '; también te interesa profundizar en algo que ya existe')
    elif flags['no_change']:
        related_value = next((v for v in obj['values'] if 'a tu manera' in v['clause']), None)
        if related_value:
            opening = phrases([related_value]) + ' es importante para ti, y ' + clause('no_change')
        else:
            opening = clause('no_change')
    elif flags['change_unknown']:
        opening = phrases(obj['values']) + ' te importa' + ('; ' if reflective_rule else connect('C_VALUES_WITH_UNKNOWN_CHANGE', ', aunque ', fallback=', y ')) + clause('change_unknown') if obj['values'] else clause('change_unknown')
    elif obj['values']:
        opening = 'te importa ' + phrases(obj['values'])
    else:
        opening = clause('well') or clause('disconnected') or clause('change_unclear') or clause('dissatisfied') or clause('desire_before')
    exploration_wish = [x for x in obj['desired_changes'] if 'P24_O11' in x['evidence_ids']]
    if flags['wants_exploration'] and not exploration_wish and not flags['change_unknown']:
        opening += grounded(['curiosity'], '; tu interés por explorar está presente')
    middle = ''
    if flags['care']:
        # A selected responsive pair belongs together. With care it is placed
        # beside agency in the fourth sentence, rather than inside the account
        # of limits, safety and the partner's reaction.
        keys = ('affective',) if 'R_RESPONSIVE' in chosen_ids else ('desire_before', 'affective')
        middle = join([clause(k) for k in keys])
        p, r = clause('pleasure'), clause('reciprocity')
        if p or r:
            # Simultaneous observations do not by themselves authorize tension.
            middle += ('; ' if middle else '') + join([p, r])
    elif body_narrative:
        condition = clause('body_condition')
        present = join([clause(k) for k in ('body_sensations', 'pleasure')])
        connective = connect('C_BODY_RESOURCE_CONTRAST', ', pero también ') if condition and present and flags['body_resource_present'] else '; '
        middle = condition + connective + present if condition and present else condition or present
    elif flags['change_unknown']:
        state = clause('disconnected')
        if state:
            state = grounded(['disconnected'], 'hoy te sientes desconectada')
        middle = join([state, clause('pleasure')])
        relationship = closeness()
        if relationship:
            middle += ('; ' if middle else '') + relationship
    elif flags['closeness_split']:
        middle = closeness()
        encounter = experience()
        if encounter:
            middle += ('; ' if middle else '') + encounter
        if flags['no_change'] and not no_change_synthesis:
            gap = clause('gap')
            if gap:
                middle = gap + '; ' + middle
    elif flags['wants_freedom'] and flags['wants_exploration']:
        # Privacy in P29 frees space for other present observations; it does not
        # turn into a negative or uncertainty clause.
        resource_keys = ['limits', 'agency']
        if flags['internal_difficulty']:
            resources = join([clause(k) for k in resource_keys])
            if 'S_INTERNAL_SCOPES_DISTINCT' in surface_permissions:
                middle = synthesis('S_INTERNAL_SCOPES_DISTINCT', resource_keys + ['internal_permission'],
                                   'decidir, expresar límites y reconocer tus intereses tienen alcances distintos: ' + resources + '; ' + clause('internal_permission'))
            else:
                connective = connect('C_INTERNAL_RESOURCE_CONTRAST', ', aunque ') if flags['positive_limits'] or flags['positive_agency'] else '; '
                middle = resources + connective + clause('internal_permission')
        else:
            middle = join([clause(k) for k in resource_keys])
            resources = join([clause(k) for k in ('affective', 'reciprocity')])
            if resources:
                middle += ('; también ' if middle else '') + resources
    elif flags['responsive'] and 'R_RESPONSIVE' in chosen_ids:
        if desire_space:
            # Editorial 02: distinguish resources from the wish for more desire.
            middle = join([clause('agency'), closeness()])
            reciprocity = clause('reciprocity')
            if reciprocity:
                middle += ('; ' if middle else '') + reciprocity
            middle = synthesis('S_WISH_RESOURCES', ['agency', 'affective', 'erotic', 'reciprocity'],
                               'ese deseo encuentra recursos presentes: ' + middle) or middle
        else:
            middle = responsive_pair()
            enjoyment = experience()
            if enjoyment:
                middle += '; ' + enjoyment
    else:
        encounter = experience()
        if chosen_ids & {'R_BOUNDED_PRESENT', 'R_DESIRE_VARIABLE_PLEASURE'} and 'desire_before' not in used:
            before = clause('desire_before')
            if 'S_DESIRE_PLEASURE_DISTINCT' in surface_permissions:
                encounter = synthesis('S_DESIRE_PLEASURE_DISTINCT', ['desire_before', 'pleasure'],
                                      'tener ganas y disfrutar tienen matices distintos: ' + join([before, clause('pleasure')]))
                reciprocity = clause('reciprocity')
                if reciprocity:
                    encounter += '; ' + reciprocity
            else:
                encounter = before + ', y ' + encounter if encounter else before
        relationship = closeness()
        middle = encounter + '; ' + relationship if encounter and relationship else encounter or relationship
    closing, fourth = '', ''
    if flags['care']:
        limits, safety, reaction = [clause(k) for k in ('limits', 'safety', 'partner_response')]
        if flags['limits_cannot'] and flags['safety_no']:
            closing = grounded(['limits', 'safety'], 'cuando quieres decir que no o parar, sientes que no puedes hacerlo y no te sientes segura para expresarlo')
        else:
            closing = limits
        if safety and not (flags['limits_cannot'] and flags['safety_no']):
            # Retain explicit differences between ability and felt safety.
            connective = connect('C_INABILITY_SAFETY_CONTRAST', ', aunque ') if flags['limits_cannot'] and flags['positive_safety'] else ' y '
            if closing:
                safety = grounded(['safety'], safety.replace('para decir que no o parar', 'al expresarlo'))
                closing += connective + safety
            else:
                closing = safety
        if reaction:
            closing += '; ' + reaction if closing else reaction
        fourth = clause('agency')
        if fourth and 'S_AGENCY_LIMIT_SCOPES' in surface_permissions:
            fourth = synthesis('S_AGENCY_LIMIT_SCOPES', ['agency'], fourth + '; ese margen para decidir y lo que ocurre al poner límites son distintos')
        if 'R_RESPONSIVE' in chosen_ids:
            pair = responsive_pair()
            fourth = fourth + '; ' + pair if fourth else pair
    elif flags['change_unknown']:
        closing = clause('agency')
        body = clause('body_sensations_uncertain')
        if body and flags['positive_agency'] and 'curiosity' in facts:
            closing += grounded(['curiosity', 'body_sensations_uncertain'], ', y tu curiosidad está presente junto a las preguntas que hoy tienes sobre qué sensaciones agradables identificas en tu cuerpo')
        elif body:
            closing += (', mientras ' if closing else '') + body
        fourth = clause('gap') if flags['gap_unknown'] else ''
        if reflective_rule:
            # Approved realization of existing facts; the closing is an
            # invitation to reflect, not a new observation or answer request.
            opening = 'te importa ' + phrases(obj['values']) + grounded(
                ['change_unknown', 'gap'],
                '; aún no tienes claro qué quisieras mover ni cuán cerca está tu vida erótica de cómo te gustaría vivirla')
            closing = grounded(['body_sensations_uncertain', 'agency'],
                               'aún no sabes qué sensaciones agradables identificas en tu cuerpo ni cuánto puedes decidir sobre tu vida erótica')
            if ('P13_O06' in facts.get('affective', {}).get('evidence_ids', [])
                    and 'P14_O07' in facts.get('erotic', {}).get('evidence_ids', [])):
                middle = grounded(['disconnected'], 'hoy te sientes desconectada') + ' y ' + clause('pleasure')
                middle += grounded(['affective', 'erotic'], '; con tu pareja, la cercanía afectiva varía y la erótica no está clara')
            fourth = grounded(['curiosity'], reflective_rule['text'])
            reflection_trace.append({'rule_id': reflective_rule['rule_id'],
                                     'type': 'REFLECTIVE_INVITATION',
                                     'evidence_ids': reflective_rule['evidence_ids'],
                                     'text': reflective_rule['text'],
                                     'requires_answer': False})
    elif body_narrative:
        present = join([clause(k) for k in ('affective', 'agency')])
        difficulties = join([clause(k) for k in ('body_registration', 'body_comfort')])
        history = clause('miss')
        closing = history + ', mientras ' + present if history and present else history or present
        if difficulties and closing:
            # A present pleasant-zone report is not ease of bodily registration
            # or comfort. Keep this distinction without burying agency in it.
            fourth = difficulties
            if 'S_BODY_REGISTERS_DISTINCT' in surface_permissions:
                fourth = synthesis('S_BODY_REGISTERS_DISTINCT', ['pleasure', 'body_sensations', 'body_registration', 'body_comfort'],
                                   'el disfrute y la relación con tu cuerpo muestran registros distintos: ' + difficulties)
        elif difficulties:
            closing = difficulties
    elif flags['closeness_split']:
        closing = join([clause(k) for k in ('agency', 'retry')
                        if k != 'retry' or 'R_ENCOUNTER_RESPONSE' not in chosen_ids])
        limits, response = clause('limits'), clause('partner_response')
        if not flags['no_change'] and limits:
            has_resource = flags['positive_agency'] or 'retry' in facts
            connective = connect('C_LIMITS_RESOURCE_CONTRAST', ', aunque ') if flags['limits_difficulty'] and has_resource else '; '
            closing += (connective if closing else '') + limits
            if response:
                if flags['limits_difficulty'] and flags['respect_response']:
                    shortened = response.removesuffix(' cuando lo expresas')
                    closing += connect('C_LIMITS_RESPECT_CONTRAST', ' incluso cuando ') + grounded(['partner_response'], shortened)
                else:
                    closing += '; ' + response
        elif no_change_synthesis:
            distance = ('la distancia importante que también reconoces respecto de cómo te gustaría vivirla'
                        if 'P02_O04' in facts['gap']['evidence_ids']
                        else 'lo lejos que sientes tu vida erótica de cómo te gustaría vivirla')
            fourth = grounded(['no_change', 'pleasure', 'gap'], 'tu elección de no mover nada ahora está presente junto a lo que disfrutas y a ' + distance)
    elif flags['wants_freedom'] and flags['wants_exploration']:
        resources = join([clause(k) for k in ('affective', 'reciprocity') if k not in used])
        context = clause('material_privacy') if 'material_privacy' in facts else ''
        if resources and context:
            closing = 'en el vínculo, ' + resources + '; en lo cotidiano, ' + context
        elif context:
            closing = 'ese interés por explorar tiene lugar junto a una condición cotidiana concreta: ' + context
        else:
            closing = resources or clause('gap')
    else:
        if desire_space:
            closing = responsive_pair()
        relationship = closeness() if 'affective' not in used and 'erotic' not in used else ''
        agency = clause('agency') if 'agency' not in used else ''
        remaining = join([relationship, agency])
        if remaining:
            closing += ('; ' if closing else '') + remaining
        if 'R_TIME' in chosen_ids and 'time' in facts:
            closing += ('; ' if closing else '') + clause('time')
        elif 'gap' in facts and 'gap' not in used and not flags['gap_unknown']:
            if 'gap' in facts and 'well' in used and 'P02_O06' in facts['gap']['evidence_ids']:
                # Same self-assessment already conveyed by P01 wellbeing: keep
                # both sources in one statement rather than repeating it.
                grounded(['well', 'gap'], 'te sientes bien con tu vida erótica')
            else:
                closing += ('; ' if closing else '') + clause('gap')
    # Explicit deepening answers modify only their declared scope. A wish to
    # explore never overrides a present pause; limited agency keeps its named
    # restrictions without converting dependence into a diagnosis of control.
    if chosen_ids & {'R_ENCOUNTER_PAUSE', 'R_ENCOUNTER_RESPONSE'}:
        response = clause('encounter_response')
        if response:
            response = grounded(['encounter_response'] + (['retry'] if 'retry' in facts else []),
                                'ante encuentros que no disfrutas, ' + response)
            closing += ('; ' if closing else '') + response
    if 'R_AUTONOMY_SOURCES' in chosen_ids:
        restriction = clause('autonomy_sources')
        if restriction:
            if 'agency' not in used:
                restriction = clause('agency') + '; ' + restriction
            closing += ('; ' if closing else '') + restriction
    if 'R_ORGASM_SCOPE' in chosen_ids:
        detail = clause('orgasm_experience')
        if detail:
            closing += ('; ' if closing else '') + 'en esa exploración, ' + detail
    if 'R_FEELING_DESIRED' in chosen_ids:
        detail = clause('feeling_desired')
        if detail:
            closing += ('; ' if closing else '') + 'ese deseo de sentirte más deseada aparece junto a lo que hoy reconoces: ' + detail
    if 'R_DAILY_CONDITIONS' in chosen_ids:
        closing += ('; ' if closing else '') + join([clause('daily_impact'), clause('daily_burdens')])
    if chosen_ids & {'R_EXPLORE_FAMILIAR', 'R_EXPLORATION_MISMATCH'}:
        detail = clause('exploration_style')
        if detail:
            if 'R_EXPLORATION_MISMATCH' in chosen_ids:
                detail = grounded(['curiosity', 'exploration_style'],
                                  'tu interés por explorar no coincide con las formas de exploración que se te ofrecieron: ' + detail)
            else:
                detail = grounded(['curiosity', 'exploration_style'],
                                  'en ese interés por explorar también aparece lo conocido: ' + detail)
            closing += ('; ' if closing else '') + detail
        if 'curiosity' not in used:
            # A wish already explicitly rendered also anchors curiosity without
            # repeating it as a separate sentence.
            if exploration_wish:
                grounded(['curiosity'], 'experimentar cosas nuevas')
            else:
                opening += grounded(['curiosity'], '; tu interés por explorar está presente')
    if 'R_INTERNAL_NO_DIFFICULTY' in chosen_ids:
        closing += ('; ' if closing else '') + clause('internal_permission')
    if 'R_AUTONOMY_UNSPECIFIED' in chosen_ids:
        closing += ('; ' if closing else '') + clause('autonomy_detail_state')
    # Ensure indispensable body/internal distinctions survive other narrative
    # families (e.g. a care scope alongside bodily conditions).
    if 'S_WELL_WITH_MATICES' in surface_permissions and not flags['care']:
        # The global self-assessment is retained alongside the local reports;
        # neither is recast as the cause or the truth of the other.
        value_items = [v for v in obj['values'] if set(v['evidence_ids']) & {'P22_O01', 'P22_O12'}]
        phrases(value_items)
        opening = synthesis('S_WELL_WITH_MATICES', ['pleasure', 'desire_before'],
                            'el placer y el juego tienen un lugar importante en lo que valoras, mientras ' + clause('pleasure') + ' y ' + clause('desire_before'))
        emissions.append({'text': 'el placer y el juego tienen un lugar importante en lo que valoras',
                          'claims': [{'claim': v['clause'], 'evidence_ids': v['evidence_ids']} for v in value_items]})
        middle = synthesis('S_WELL_WITH_MATICES', ['gap', 'erotic'],
                           'sentirte bien con tu vida erótica convive con una distancia marcada con tu pareja en lo erótico: tu valoración del conjunto y lo que experimentas en cada aspecto tienen matices diferentes')
        closing = clause('agency') + ', y esta combinación invita a preguntarte qué sostiene hoy esa sensación de bienestar'
        reflection_trace.append({'rule_id': 'RF_WELL_WITH_MATICES', 'type': 'REFLECTIVE_INVITATION',
                                 'evidence_ids': surface_permissions['S_WELL_WITH_MATICES']['evidence_ids'],
                                 'text': 'esta combinación invita a preguntarte qué sostiene hoy esa sensación de bienestar',
                                 'requires_answer': False})
        fourth = ''
    draft_now = ' '.join(sentence(x) for x in (opening, middle, closing, fourth) if x).casefold()
    emitted = {c['claim'] for e in emissions if e['text'].casefold() in draft_now for c in e['claims']}
    extra = []
    completed_relations = []
    for r in selected:
        missing = [k for k in RELATION_FACT_KEYS[r['rule_id']] if k in facts and k not in emitted]
        if not missing:
            continue
        completed_relations.append(r['rule_id'])
        additions = []
        if {'desire_before', 'desire_during'} <= set(missing):
            additions.append(responsive_pair())
            emitted.update(('desire_before', 'desire_during'))
            missing = [k for k in missing if k not in ('desire_before', 'desire_during')]
        for key in missing:
            # A compound realization may already have emitted this source
            # while adding another anchor (e.g. condition with body details).
            # Do not append the same observation again in the same pass.
            added_text = ' '.join(additions).casefold()
            if any(e['text'].casefold() in added_text and
                   any(c['claim'] == key for c in e['claims']) for e in emissions):
                emitted.add(key)
                continue
            if key == 'desire_during':
                text = 'cuando al principio no tienes ganas, ' + facts[key]['clause'].replace('aumentan', 'el deseo aumenta')
                additions.append(grounded([key], text))
            else:
                additions.append(clause(key))
            emitted.add(key)
        if r['priority'] == 1:
            if (r['rule_id'] == 'R_EXPRESSION_RESPECT'
                    and 'S_EXPRESSION_RESPECT_SCOPES' in surface_permissions
                    and {'limits', 'partner_response'} <= set(missing)):
                additions = [synthesis('S_EXPRESSION_RESPECT_SCOPES', ['limits', 'partner_response'],
                                       'el respeto de tu pareja y la facilidad para expresar tus límites son aspectos distintos: ' + join([clause('limits'), clause('partner_response')]))]
            extra.extend(additions)
        else:
            # A lower-priority relationship does not authorize a fourth sentence.
            # Keep its selected anchors in the existing closing; editorial QA
            # still needs to assess density and relational synthesis.
            closing += ('; ' if closing else '') + join(additions)
    if 'R_MATERIAL_PRIVACY' in chosen_ids and not flags['material_privacy_limited'] and 'privacy_report' in facts:
        extra.append(clause('privacy_report'))
    # Asking for greater comfort/registration must never imply that these are
    # absent. Preserve an explicitly reported favorable state when another
    # selected relationship determines the narrative family.
    body_background = []
    if flags['body_focus'] and not body_narrative:
        for key in ('body_registration', 'body_comfort'):
            positive = key in {r['kind'] for r in obj['present_resources']}
            if positive and key not in emitted:
                body_background.append(clause(key))
                emitted.add(key)
    if body_background:
        fourth += ('; ' if fourth else '') + 'en esa relación con tu cuerpo también hay algo que ya está presente: ' + join(body_background)
    if extra:
        fourth += (', mientras ' if fourth else '') + join(extra)
    # Preserve a reported state beside stated wishes; do not tidy a complex
    # profile by silently discarding disconnection or uncertainty from P01.
    state_text = ' '.join(sentence(x) for x in (opening, middle, closing, fourth) if x).casefold()
    if 'disconnected' in facts and not any(
            e['text'].casefold() in state_text and any(c['claim'] == 'disconnected' for c in e['claims'])
            for e in emissions):
        wording = ('; a la vez, te sientes desconectada y aún no sabes bien qué quieres'
                   if wishes else '; también señalas desconexión e incertidumbre sobre lo que quieres')
        opening += grounded(['disconnected'], wording)
    # Enjoyment remains an independent present report when a wishes/limits
    # narrative consumes the selected relationships. Do not let the framing
    # make variable or low enjoyment disappear from the whole-map reading.
    enjoyment_text = ' '.join(sentence(x) for x in (opening, middle, closing, fourth) if x).casefold()
    if 'pleasure' in facts and not any(
            e['text'].casefold() in enjoyment_text and
            any(c['claim'] == 'pleasure' for c in e['claims']) for e in emissions):
        middle += ('; ' if middle else '') + clause('pleasure')
    # Coexistence is shown by the paragraph. A second "para ti" does not add
    # another distinction in the same reading.
    if any('para ti' in x for x in (opening, closing, fourth)):
        middle = middle.replace(' no está clara para ti', ' no está clara')
        if 'affective' in facts and 'P13_O07' in facts['affective']['evidence_ids']:
            grounded(['affective'], 'la cercanía afectiva con tu pareja no está clara')
    # Redistribute complete scoped clauses, never cut a clause or add a new
    # sentence to meet a length score. Preserve the approved grouping in 02.
    if not desire_space and not reflective_rule and not flags['no_change'] and not body_narrative:
        slots = [middle, closing, fourth]
        for _ in range(4):
            lengths = [len(x.split()) for x in slots]
            best = None
            old_cost = (max(lengths), sum(n*n for n in lengths))
            for i in range(2):
                if not slots[i] or not slots[i+1]:
                    continue
                for direction in (1, -1):
                    source = i if direction == 1 else i+1
                    if '; ' not in slots[source]:
                        continue
                    candidate = list(slots)
                    if direction == 1:
                        head, tail = candidate[i].rsplit('; ', 1)
                        moved = tail
                        candidate[i], candidate[i+1] = head, tail + '; ' + candidate[i+1]
                    else:
                        head, tail = candidate[i+1].split('; ', 1)
                        moved = head
                        candidate[i], candidate[i+1] = candidate[i] + '; ' + head, tail
                    if flags['care'] and any(marker in moved for marker in (
                            'oportunidad que eliges darte', 'sientes que no puedes',
                            'no te sientes segura', 'te resulta fácil expresar',
                            'te cuesta expresar', 'decir que no o parar',
                            'respuesta de tu pareja', 'tu pareja lo respeta',
                            'tu pareja generalmente', 'tu pareja a veces',
                            'tu pareja muchas veces')):
                        continue
                    new_lengths = [len(x.split()) for x in candidate]
                    cost = (max(new_lengths), sum(n*n for n in new_lengths))
                    if cost < old_cost and (best is None or cost < best[0]):
                        best = (cost, candidate)
            if best is None:
                break
            slots = best[1]
        middle, closing, fourth = slots
    parts = [sentence(x) for x in (opening, middle, closing, fourth) if x]
    final_text = ' '.join(parts).casefold()
    trace = [c for e in emissions if e['text'].casefold() in final_text for c in e['claims']]
    trace = list({(c['claim'], tuple(c['evidence_ids'])): c for c in trace}.values())
    summary_sources = {i for c in trace for i in c['evidence_ids']}
    present_desire_in_summary = bool(set(facts.get('desire_present', {}).get('evidence_ids', [])) & summary_sources)
    # Title is separately traceable to the same closed observations/selected
    # relations; no extra observation or implicit global freedom is introduced.
    if flags['care'] and flags['low_agency']:
        name, name_claims = 'Deseo con poco margen' if wishes or present_desire_in_summary else 'Límites y poco margen', ['agency']
    elif flags['care']:
        name, name_claims = ('Deseo entre tensiones' if wishes or present_desire_in_summary else
                             'Tus límites hoy' if flags['no_partner_candidate'] else 'Tus límites en el vínculo'), ['limits', 'partner_response', 'safety']
    elif 'R_EXPLORATION_MISMATCH' in chosen_ids:
        name, name_claims = 'Curiosidad y matices', ['curiosity', 'exploration_style']
    elif 'S_WELL_WITH_MATICES' in surface_permissions:
        name, name_claims = 'Bienestar con matices', ['gap', 'pleasure', 'erotic']
    elif flags['change_unknown'] and flags['positive_agency'] and 'curiosity' in facts:
        name, name_claims = 'Curiosidad con margen propio', ['agency']
    elif flags['change_unknown'] and 'curiosity' in facts:
        name, name_claims = 'Curiosidad en la incertidumbre', ['change_unknown']
    elif flags['wants_freedom']:
        name, name_claims = 'Deseo de libertad', []
    elif body_narrative:
        if flags['positive_pleasure'] and flags['confirmed_body_condition']:
            name, name_claims = 'Placer entre cambios', ['pleasure', 'body_condition']
        else:
            name, name_claims = 'El cuerpo en tu mirada', []
    elif flags['no_change'] and flags['closeness_split']:
        name, name_claims = 'Distancia con disfrute presente' if flags['positive_pleasure'] else 'Tu decisión de hoy', ['erotic', 'pleasure']
    elif flags['closeness_split']:
        if flags['wants_reciprocity'] and flags['wants_expression']:
            name, name_claims = 'Tu placer y tu voz', ['reciprocity', 'limits']
        else:
            name, name_claims = 'Cercanía en distintos planos', ['affective', 'erotic']
    elif flags['no_change']:
        name, name_claims = 'Tu decisión de hoy', ['no_change']
    elif flags['wants_exploration'] and flags['positive_pleasure']:
        name, name_claims = 'Explorar desde el disfrute', ['pleasure']
    elif any(i == 'P24_O01' for d in obj['desired_changes'] for i in d['evidence_ids']):
        name, name_claims = 'Un lugar para el deseo', []
    elif obj['desired_changes']:
        name, name_claims = 'Lo que hoy deseas', []
    else:
        name, name_claims = 'Tu momento actual', []
    name_trace = [facts[k]['evidence_ids'] for k in name_claims if k in facts]
    if name == 'El cuerpo en tu mirada':
        name_trace = [x['evidence_ids'] for x in obj['desired_changes']
                      if set(x['evidence_ids']) & {'P24_O05', 'P24_O06'}]
    elif name == 'Deseo de libertad':
        name_trace = [x['evidence_ids'] for x in obj['desired_changes'] if 'P24_O13' in x['evidence_ids']]
    elif name == 'Un lugar para el deseo':
        name_trace = [x['evidence_ids'] for x in obj['desired_changes'] if 'P24_O01' in x['evidence_ids']]
    elif name == 'Explorar desde el disfrute':
        name_trace += ([x['evidence_ids'] for x in exploration_wish] or [facts['curiosity']['evidence_ids']])
    if name.startswith('Curiosidad') and 'curiosity' in facts:
        summary_sources = {i for c in trace for i in c['evidence_ids']}
        interest = [i for i in facts['curiosity']['evidence_ids'] if i in summary_sources]
        if interest:
            name_trace.append(interest)
        else:
            name, name_trace = 'Tu momento actual', []
    if name.startswith('Deseo') and name != 'Deseo de libertad':
        name_trace += [x['evidence_ids'] for x in obj['desired_changes']]
        if not obj['desired_changes'] and flags['desire_present']:
            # A wish alone grounds a desire title. Do not add an unrendered
            # occurrence, particularly when the responsive rule was not chosen.
            summary_sources = {i for c in trace for i in c['evidence_ids']}
            occurrence = [i for i in facts['desire_present']['evidence_ids'] if i in summary_sources]
            if occurrence:
                name_trace.append(occurrence)
    if not name_trace:
        name_trace = [x['evidence_ids'] for x in obj['desired_changes']] or [x['evidence_ids'] for x in obj['values']]
        if not name_trace:
            name_trace = [c['evidence_ids'] for c in trace]
    output = {'configuration_name': name, 'summary': ' '.join(parts),
            'claim_trace': trace, 'name_evidence': name_trace,
            'connector_trace': connector_trace,
            'reflection_trace': reflection_trace,
            'synthesis_trace': synthesis_trace,
            'selected_relations': [r['rule_id'] for r in selected], 'relation_exception': exception,
            'completed_relation_anchors': completed_relations,
            'fourth_sentence_reason': ('essential_relation_scope' if extra else 'care_scope' if flags['care'] else 'body_wish_does_not_establish_absence' if body_background else 'body_registration_comfort_distinction' if body_narrative else 'agency_choice_distinction' if no_change_synthesis else 'uncertainty_scope') if fourth else None,
            'status': 'DRAFT_EDITORIAL_REVIEW' if not exception else 'EXTENDED_DRAFT_EDITORIAL_REVIEW',
            'sentence_count': len(parts), 'version': VERSION,
            'limitations': 'Bounded frozen composition contract; arbitrary generated readings remain editorial drafts, not an integrated or participant-validated release'}
    output['delivery_eligible'] = False
    if flags['no_partner_candidate']:
        output['population_scope'] = 'OUTSIDE_TARGET_POPULATION'
    output['contract_audit'] = audit_output(obj, output)
    if output['contract_audit']['errors']:
        output['status'] = 'RECOMPOSITION_REQUIRED'
    return output

def audit_output(obj, output):
    """Mechanical delivery checks, not editorial or semantic approval.

    Name and summary share a single selected-rule budget. Background facts and
    declared wishes remain traceable; no membership check certifies a relation.
    """
    actual = {i for f in obj['facts'].values() for i in f['evidence_ids']}
    actual.update(i for x in obj['values'] + obj['desired_changes'] for i in x['evidence_ids'])
    used = {i for c in output['claim_trace'] for i in c['evidence_ids']}
    named = {i for group in output['name_evidence'] for i in group}
    private = {i for c in obj['constraints'] if c['kind'] == 'privacy' for i in c['evidence_ids']}
    errors = []
    title_rule = next((r for r in COMPOSITION_CATALOG.get('title_rules', [])
                       if r['title'] == output['configuration_name']), None)
    if title_rule is None:
        errors.append('TITLE_OUTSIDE_CLOSED_CATALOGUE')
    else:
        condition = title_rule['when']
        wish_ids = {i for w in obj['desired_changes'] for i in w['evidence_ids']}
        selected_ids = set(output['selected_relations'])
        surface_ids = {r['rule_id'] for r in obj.get('surface_permissions', [])
                       if set(r['parent_relations']) & selected_ids}
        eligible = (all(obj['flags'].get(k, False) for k in condition.get('flags_all', []))
                    and all(k in obj['facts'] for k in condition.get('facts_all', []))
                    and (not condition.get('wish_ids_any') or bool(wish_ids & named & set(condition['wish_ids_any'])))
                    and (not condition.get('selected_any') or bool(selected_ids & set(condition['selected_any'])))
                    and (not condition.get('surface_any') or bool(surface_ids & set(condition['surface_any']))))
        if not eligible:
            errors.append('TITLE_WITHOUT_REQUIRED_MEANING')
        if condition.get('wish_or_present_desire'):
            desire_sources = set(obj['facts'].get('desire_present', {}).get('evidence_ids', []))
            if not ((wish_ids | desire_sources) & named & used):
                errors.append('DESIRE_TITLE_WITHOUT_EMITTED_DESIRE')
        if obj['flags']['care']:
            allowed = ({'Deseo con poco margen','Límites y poco margen'} if obj['flags']['low_agency']
                       else {'Deseo entre tensiones','Tus límites en el vínculo','Tus límites hoy'})
            if output['configuration_name'] not in allowed:
                errors.append('TITLE_IGNORES_CARE_PRECEDENCE')
    treatments = obj.get('option_treatment', {})
    if any(v['role']=='UNDEFINED_OPTION_TREATMENT' for v in treatments.values()):
        errors.append('UNDEFINED_OPTION_TREATMENT')
    forbidden_roles = {'CONTEXT_HISTORY_ONLY', 'LITERAL_ELICITATION_ONLY', 'PRIVACY_ONLY', 'UNRESOLVED_PARTNER_REFERENT'}
    if any(treatments.get(i, {}).get('role') in forbidden_roles for i in used | named):
        errors.append('OPTION_ROLE_DOES_NOT_AUTHORIZE_PROSE')
    if not used <= actual or not named <= actual:
        errors.append('UNSUPPORTED_SOURCE')
    if not named <= used:
        errors.append('NAME_OUTSIDE_SUMMARY_EVIDENCE')
    if (used | named) & private:
        errors.append('PRIVACY_CONTENT')
    if len(output['selected_relations']) > 3 and not output['relation_exception']:
        errors.append('UNAUTHORIZED_RELATION_OVERFLOW')
    if output['sentence_count'] > 3 and not output['fourth_sentence_reason']:
        errors.append('UNAUTHORIZED_FOURTH_SENTENCE')
    if output['fourth_sentence_reason'] and output['fourth_sentence_reason'] not in COMPOSITION_CATALOG['selection']['fourth_sentence']['allowed_reasons']:
        errors.append('UNKNOWN_FOURTH_SENTENCE_REASON')
    used_keys = {c['claim'] for c in output['claim_trace']}
    missing_anchors = {}
    for rule_id in output['selected_relations']:
        missing = set(RELATION_FACT_KEYS[rule_id]) & set(obj['facts']) - used_keys
        if missing:
            missing_anchors[rule_id] = sorted(missing)
    if missing_anchors:
        errors.append('SELECTED_RELATION_ANCHORS_MISSING')
    actual_connectors = Counter(re.findall(r'\b(?:aunque|pero también|pero|incluso cuando)\b', output['summary'].casefold()))
    recorded_connectors = Counter(c['phrase'] for c in output.get('connector_trace', []))
    if actual_connectors != recorded_connectors:
        errors.append('UNRECORDED_INTERPRETIVE_CONNECTOR')
    permissions = {r['connector_id']: r for r in obj['connector_permissions']}
    def connector_supported(c):
        permission = permissions.get(c['connector_id'])
        return (permission is not None and c['authorized'] and
                set(c['evidence_ids']) == set(permission['evidence_ids']) and
                set(c['evidence_ids']) <= used and
                set(c.get('parent_relations', [])) == set(permission.get('parent_relations', [])) & set(output['selected_relations']) and
                bool(c.get('parent_relations')) and
                c['phrase'] in permission.get('allowed_phrases', []) and
                (not permission.get('required_relation') or permission['required_relation'] in output['selected_relations']))
    if any(not connector_supported(c) for c in output.get('connector_trace', [])):
        errors.append('CONNECTOR_WITHOUT_EMITTED_SUPPORT')
    surfaces = {r['rule_id']: r for r in obj.get('surface_permissions', [])}
    for realization in output.get('synthesis_trace', []):
        permission = surfaces.get(realization['rule_id'])
        if (permission is None or set(realization['evidence_ids']) != set(permission['evidence_ids'])
                or not set(realization['evidence_ids']) <= used
                or not set(realization['parent_relations']) == set(permission['parent_relations']) & set(output['selected_relations'])):
            errors.append('UNSUPPORTED_RELATIONAL_SYNTHESIS')
    reflections = {r['rule_id']: r for r in obj.get('reflective_permissions', [])}
    for reflection in output.get('reflection_trace', []):
        permission = reflections.get(reflection['rule_id'])
        if (permission is None or reflection['text'] != permission['text']
                or reflection['requires_answer'] is not False
                or set(reflection['evidence_ids']) != set(permission['evidence_ids'])
                or not set(reflection['evidence_ids']) <= used
                or not set(permission['required_relations']) <= set(output['selected_relations'])
                or obj['flags']['care']):
            errors.append('UNSUPPORTED_REFLECTIVE_INVITATION')
    return {'errors': errors, 'shared_selected_relations': output['selected_relations'],
            'missing_relation_anchors': missing_anchors,
            'semantic_relation_audit': 'CONTROLLED_CONNECTORS_CHECKED_NOT_COMPLETE_PROSE_VALIDATION', 'editorial_approval': 'PENDING',
            'catalogue_gap_is_not_missing_participant_answers': True}

def compose(snapshot):
    return render_object(compile_object(snapshot))

def compose_session(request):
    """Versioned draft interface. COMPLETE and delivery are separate states.

    The instrument fingerprint covers the packaged V4 input contract, including
    source-document hash, labels, states and versioned schema. The executable
    branch logic is separately checked and hashed in the package manifest.
    This does not authorize production use or expand A/B entry eligibility.
    A malformed integration request is a caller error, not a new participant task.
    """
    error = request_error(request, schema=SNAPSHOT_SCHEMA,
                          fingerprint=INSTRUMENT_FINGERPRINT,
                          composition_version=VERSION)
    if error:
        # Codes only: never participant text or exception details.
        raise ValueError(error[0])
    output = compose(request['snapshot'])
    return {'session_id': request['session_id'], 'assessment_status': 'COMPLETE',
            'snapshot_schema': SNAPSHOT_SCHEMA,
            'instrument_fingerprint': INSTRUMENT_FINGERPRINT,
            'composition_version': VERSION, 'output': output,
            'instrument_version': json.loads((ROOT.parent/'contrato_instrumento_v4.json').read_text(encoding='utf-8'))['instrument_version'],
            'response_records': copy.deepcopy(request['snapshot']['answers']),
            'production_delivery': False,
            'pending_participant_actions': []}

def compose_applicability_preview(snapshot):
    """QA wrapper for outside-target access, using the same composition path."""
    obj = compile_object(snapshot)
    output = render_object(obj)
    return {'output': output, 'applicability': obj['applicability'],
            'status': 'OUTSIDE_TARGET_SCOPE_PREVIEW',
            'instrument_changes': False, 'production_delivery': False}
