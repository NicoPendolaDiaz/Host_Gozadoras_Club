"""Executable composition-contract audit. Not a production prose generator.

Use verificar_paquete.py and verificar_compatibilidad.py in this delivery.
Synthetic answer helpers below are used by the packaged regression tests.
This validates option/state/branch contracts and relation selection, not every
nuance of Spanish prose or the deployed implementation.
"""
import copy
import json
import re
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OPTIONS = json.loads((ROOT / 'canonical_options.json').read_text(encoding='utf-8'))
INPUT_CONTRACT = json.loads((ROOT.parent/'contrato_instrumento_v4.json').read_text(encoding='utf-8'))
MEDICATION_OPTIONS = INPUT_CONTRACT['medication_labels']
if OPTIONS != INPUT_CONTRACT['option_labels']:
    raise ValueError('ENGINE_CANONICAL_OPTIONS_MISMATCH')

def oid(q, n):
    return f'P{q:02d}_O{n:02d}'

def state(ids):
    # V4: «No sé todavía» es answered; su incertidumbre semántica
    # se conserva en el Object, sin cambiar el registro de la participante.
    classifications = {'No sé':'dont_know', 'No lo tengo claro':'not_clear',
                       'Prefiero no responder':'prefer_not_to_answer'}
    codes = {classifications.get(OPTIONS.get(i, MEDICATION_OPTIONS.get(i)), 'answered') for i in ids}
    for code in ('prefer_not_to_answer', 'not_clear', 'dont_know'):
        if code in codes:
            return code
    return 'answered'

def has(f, q, *ns):
    return bool(set(f['answers'][f'P{q:02d}']['option_ids']) & {oid(q, n) for n in ns})

CORE = {1, 2, 6, 8, 9, 10, 13, 14, 15, 16, 19, 21, 22, 24}
ALWAYS = CORE | {3, 11, 23}

def branches(f):
    # Topological evaluation: a hidden parent's residual response never opens
    # a descendant. Validation still rejects the residual parent itself.
    active = {q: ('necessary' if q in CORE else 'optional') for q in ALWAYS}
    def live(q, *ns):
        return q in active and has(f, q, *ns)
    def enable(q, condition, role='necessary'):
        if condition:
            active[q] = role
    enable(4, live(1, 2, 3, 6), 'optional')
    enable(5, live(4, 1), 'optional')
    enable(7, live(6, 1, 2))
    enable(12, live(10, 4, 5, 6))
    enable(17, live(16, 3, 4, 5))
    enable(18, live(16, 5) or live(17, 3, 4, 5, 7))
    enable(20, live(19, 3, 4, 5))
    enable(25, live(24, 4))
    enable(26, live(24, 5))
    enable(27, live(24, 6))
    enable(28, live(24, 11) or live(1, 5), 'necessary' if live(24, 11) else 'optional')
    enable(29, live(24, 13) or live(22, 9), 'necessary' if live(24, 13) else 'optional')
    enable(30, live(24, 7))
    enable(31, live(24, 9), 'optional')
    enable(32, live(24, 12) or live(20, 9))
    enable(33, live(21, 4, 5))
    enable(34, live(1, 7), 'optional')
    enable(35, live(3, 14), 'optional')
    enable(36, live(22, 14), 'optional')
    enable(37, live(24, 16), 'optional')
    enable(38, live(7, 14), 'optional')
    enable(39, live(20, 10), 'optional')
    enable(40, live(33, 5), 'optional')
    return active

DEFAULTS = {4: [3], 7: [15], 12: [8], 17: [7], 18: [5], 20: [7],
            25: [10], 26: [6], 27: [6], 28: [5], 29: [4], 30: [6],
            32: [7], 33: [7]}

def answer(f, q, ns):
    ids = [oid(q, n) for n in ns]
    f['answers'][f'P{q:02d}'] = {'option_ids': ids, 'zone_ids': [], 'state_code': state(ids), 'text': None}


def expression_match(f, expression, guard_catalog=None):
    if 'zone_ids_nonempty' in expression:
        record = f['answers'].get(expression.get('question_id'), {})
        return bool(record.get('zone_ids')) == expression['zone_ids_nonempty']
    if 'not' in expression:
        return not expression_match(f, expression['not'], guard_catalog)
    if 'all' in expression:
        return all(expression_match(f, x, guard_catalog) for x in expression['all'])
    if 'any' in expression:
        return any(expression_match(f, x, guard_catalog) for x in expression['any'])
    if 'option_ids' in expression:
        return any(x in a['option_ids'] for a in f['answers'].values() for x in expression['option_ids'])
    if 'guards' in expression:
        return any(x['rule_id'] in expression['guards'] for x in guards(f, guard_catalog))
    raise ValueError(expression)

def guards(f, guard_catalog=None):
    catalog = CATALOG if guard_catalog is None else guard_catalog
    return [r for r in catalog['guards'] if expression_match(f, r['when'], catalog)]

def evidence(f, expression, guard_catalog=None):
    pool = set()
    def walk(e):
        if e.get('zone_ids_nonempty') and e.get('question_id') in f['answers']:
            pool.update(f['answers'][e['question_id']]['zone_ids'])
        for x in e.get('option_ids', []):
            if any(x in a['option_ids'] for a in f['answers'].values()):
                pool.add(x)
        for op in ('all', 'any'):
            for child in e.get(op, []):
                walk(child)
        for g in e.get('guards', []):
            catalog = CATALOG if guard_catalog is None else guard_catalog
            r = next(x for x in catalog['guards'] if x['rule_id'] == g)
            walk(r['when'])
    walk(expression)
    return sorted(pool)


MULTI_MAX = {1: 2, 7: 3, 12: 3, 20: 3, 22: 3, 24: 4}
MULTI = set(MULTI_MAX) | {3, 33}
EXCLUSIVE = {1: [7], 3: [15, 16], 7: [15], 12: [7, 8], 20: [11],
             22: [15, 16], 24: [15, 17], 33: [6, 7, 8]}
TEXT = {5, 23} | set(range(34, 41))

def validate_input(f):
    errors = []
    expected = {f'P{q:02d}' for q in range(1, 41)}
    if not isinstance(f, dict) or not isinstance(f.get('answers'), dict):
        return ['SNAPSHOT_SCHEMA: answers must be a question-record dictionary']
    if set(f['answers']) != expected | {'P03_MICRO'}:
        return ['SNAPSHOT_SCHEMA: expected P01-P40 plus P03_MICRO records']
    if not isinstance(f.get('context'), dict) or f['context'].get('current_partner') not in ('yes', 'no', 'prefer_not_to_answer'):
        return ['SNAPSHOT_SCHEMA: current_partner context is required']
    states = {'answered', 'dont_know', 'not_clear', 'prefer_not_to_answer', 'omitted', 'not_shown'}
    for key, a in f['answers'].items():
        if (not isinstance(a, dict) or not {'option_ids', 'zone_ids', 'state_code', 'text'} <= set(a)
                or not isinstance(a['option_ids'], list) or not all(isinstance(i, str) for i in a['option_ids'])
                or not isinstance(a['zone_ids'], list) or not all(isinstance(i, str) for i in a['zone_ids'])
                or not isinstance(a['state_code'], str) or a['state_code'] not in states
                or (a['text'] is not None and not isinstance(a['text'], str))):
            errors.append(key + ': record schema/state contract')
    if errors:
        return errors
    active = branches(f)
    for q in range(1, 41):
        a = f['answers'][f'P{q:02d}']; ids = a['option_ids']; zones = a['zone_ids']; s = a['state_code']
        if s in ('omitted', 'not_shown') and (ids or zones or a['text'] is not None):
            errors.append(f'P{q:02d}: unprovided state carries content')
        if q != 11 and zones:
            errors.append(f'P{q:02d}: zones only belong to P11')
        if len(zones) != len(set(zones)):
            errors.append(f'P{q:02d}: duplicate zones')
        if q not in TEXT and a['text'] is not None:
            errors.append(f'P{q:02d}: text only belongs to designated text records')
        if q in TEXT and (ids or zones or (s == 'answered' and not (a['text'] or '').strip())):
            errors.append(f'P{q:02d}: text content contract')
        if q not in active:
            if s != 'not_shown' or ids or zones or a['text']:
                errors.append(f'P{q:02d}: dormant branch carries an answer')
            continue
        if s == 'not_shown' or (active[q] == 'necessary' and s == 'omitted'):
            errors.append(f'P{q:02d}: active item unresolved')
        if any(x not in OPTIONS or not x.startswith(f'P{q:02d}_') for x in ids):
            errors.append(f'P{q:02d}: invalid option_id')
        if len(ids) != len(set(ids)):
            errors.append(f'P{q:02d}: duplicate options')
        if q not in MULTI and q not in TEXT and q != 11 and s != 'omitted' and len(ids) != 1:
            errors.append(f'P{q:02d}: single cardinality')
        if q in MULTI and s != 'omitted' and not ids:
            errors.append(f'P{q:02d}: empty multiple selection')
        if q in MULTI_MAX and len(ids) > MULTI_MAX[q]:
            errors.append(f'P{q:02d}: max cardinality')
        if len(ids) > 1 and any(oid(q, n) in ids for n in EXCLUSIVE.get(q, [])):
            errors.append(f'P{q:02d}: exclusive option combined')
        if ids and s != state(ids):
            errors.append(f'P{q:02d}: state_code mismatch')
        if q == 11 and s != 'omitted':
            if (bool(ids) == bool(zones)) or len(ids) > 1 or any(z not in {f'Z{n:02d}' for n in range(1, 10)} for z in zones):
                errors.append('P11: zones/external-state contract')
            if zones and s != 'answered':
                errors.append('P11: zones require answered state')
        if q in TEXT and s not in ('answered', 'omitted'):
            errors.append(f'P{q:02d}: text state contract')
    # P03_MICRO es un detalle de P03, nunca una pregunta 41.
    m=f['answers'].get('P03_MICRO',{'option_ids':[],'zone_ids':[],'state_code':'not_shown','text':None}); ids=m['option_ids']; st=m['state_code']
    enabled=has(f,3,4)
    if not enabled:
        if st!='not_shown' or ids or m['zone_ids'] or m['text'] is not None:
            errors.append('P03_MICRO: dormant medication detail carries an answer')
    else:
        if st in ('not_shown','omitted') or not ids:
            errors.append('P03_MICRO: active medication detail unresolved')
        if m['zone_ids'] or len(ids)!=len(set(ids)) or any(i not in {f'P03_M{n:02d}' for n in range(1,11)} for i in ids):
            errors.append('P03_MICRO: medication identifiers/cardinality')
        if len(ids)>1 and set(ids)&{'P03_M09','P03_M10'}:
            errors.append('P03_MICRO: exclusive medication option combined')
        if ids and st!=state(ids):
            errors.append('P03_MICRO: state_code mismatch')
        if m['text'] is not None and 'P03_M08' not in ids:
            errors.append('P03_MICRO: text requires other medication')
        if m['text'] is not None and not m['text'].strip():
            errors.append('P03_MICRO: empty optional text must be null')
    return errors

# Resource envelope for transport, not a participant text/character limit.
# Oversized requests are rejected whole, never truncated or reinterpreted.
MAX_REQUEST_BYTES = 8 * 1024 * 1024
MAX_JSON_DEPTH = 64
INSTRUMENT_VERSION = 'GOZADORAS-40-PREGUNTAS-EXPERIENCIA-V4-2026-10-07'

def validate_json_value(value):
    stack = [(value, 0)]
    byte_budget = 0
    nodes = 0
    while stack:
        item, depth = stack.pop()
        nodes += 1
        if depth > MAX_JSON_DEPTH:
            return ('JSON_NESTING_LIMIT', [])
        # An object passed directly must have the same finite, Unicode-valid
        # domain as JSON read by the CLI. Unknown metadata is checked as well.
        if isinstance(item, str):
            try:
                byte_budget += len(item.encode('utf-8'))
            except UnicodeError:
                return ('INVALID_UNICODE', [])
        elif isinstance(item, dict):
            if not all(isinstance(key, str) for key in item):
                return ('INVALID_JSON_VALUE', [])
            stack.extend((key, depth+1) for key in item)
            stack.extend((child, depth+1) for child in item.values())
        elif isinstance(item, list):
            stack.extend((child, depth+1) for child in item)
        elif isinstance(item, float):
            if not math.isfinite(item):
                return ('NONSTANDARD_JSON_NUMBER', [])
        elif item is not None and type(item) not in (int, bool):
            return ('INVALID_JSON_VALUE', [])
        if byte_budget > MAX_REQUEST_BYTES or nodes > MAX_REQUEST_BYTES:
            return ('REQUEST_TOO_LARGE', [])
    try:
        serialized = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
        if len(serialized.encode('utf-8')) > MAX_REQUEST_BYTES:
            return ('REQUEST_TOO_LARGE', [])
    except (ValueError, TypeError, RecursionError, UnicodeError):
        return ('INVALID_JSON_VALUE', [])
    return None

def request_error(request, *, schema, fingerprint, composition_version):
    error = validate_json_value(request)
    if error:
        return error
    required = {'session_id', 'snapshot_schema', 'instrument_fingerprint',
                'composition_version', 'snapshot'}
    if not isinstance(request, dict) or not required <= request.keys():
        return ('REQUEST_FIELDS_REQUIRED', [])
    if not isinstance(request['session_id'], str) or not request['session_id'].strip():
        return ('SESSION_ID_REQUIRED', ['session_id'])
    constants = {'snapshot_schema':schema, 'instrument_fingerprint':fingerprint,
                 'composition_version':composition_version}
    if any(request[key] != value for key, value in constants.items()):
        return ('CONTRACT_VERSION_MISMATCH', [])
    snapshot = request['snapshot']
    if not isinstance(snapshot, dict):
        return ('SNAPSHOT_REQUIRED', ['snapshot'])
    if 'session_id' in snapshot and snapshot['session_id'] != request['session_id']:
        return ('SESSION_ID_MISMATCH', ['session_id', 'snapshot.session_id'])
    if 'rules_version' in snapshot and snapshot['rules_version'] != composition_version:
        return ('RULES_VERSION_MISMATCH', ['snapshot.rules_version'])
    context = snapshot.get('context')
    if not isinstance(context, dict) or context.get('current_partner') not in ('yes','no','prefer_not_to_answer'):
        return ('PARTNER_CONTEXT_INVALID', ['snapshot.context.current_partner'])
    if snapshot.get('instrument_version') != INSTRUMENT_VERSION:
        return ('INSTRUMENT_VERSION_MISMATCH', ['snapshot.instrument_version'])
    if not isinstance(snapshot.get('answers'), dict) or set(snapshot['answers']) != {f'P{q:02d}' for q in range(1,41)} | {'P03_MICRO'}:
        return ('ANSWER_RECORDS_REQUIRED', ['snapshot.answers'])
    errors = validate_input(snapshot)
    if errors:
        fields = sorted({e.split(':')[0] for e in errors if e.split(':')[0] in snapshot['answers']})
        return ('SNAPSHOT_INVALID', fields)
    return None







CATALOG = json.loads((ROOT / 'composition_catalog.json').read_text(encoding='utf-8'))
if __name__ == '__main__':
    raise SystemExit('Run verificar_paquete.py, verificar_compatibilidad.py and verificar_estres.py from the package root.')
