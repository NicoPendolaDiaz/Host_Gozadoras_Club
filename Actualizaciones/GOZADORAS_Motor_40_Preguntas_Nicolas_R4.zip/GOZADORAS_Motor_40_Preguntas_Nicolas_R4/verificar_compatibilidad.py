"""Cobertura reproducible del contrato V4. Todos los casos son sintéticos."""
import copy
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'motor'))
import composer
import qa

EMPTY={'option_ids':[],'zone_ids':[],'state_code':'not_shown','text':None}
ACTIVATE={4:{1:[2]},5:{1:[2],4:[1]},7:{6:[1]},12:{10:[4]},
          17:{16:[4]},18:{16:[5],17:[3]},20:{19:[3]},25:{24:[4]},
          26:{24:[5]},27:{24:[6]},28:{24:[11]},29:{24:[13]},
          30:{24:[7]},31:{24:[9]},32:{24:[12]},33:{21:[4]},
          34:{1:[7]},35:{3:[14]},36:{22:[14]},37:{24:[16]},
          38:{6:[1],7:[14]},39:{19:[3],20:[10]},40:{21:[4],33:[5]}}

def build_case(overrides=None, medication=None):
    # Esta fábrica solo arma pruebas. El ejecutor nunca inventa respuestas.
    request=json.loads((ROOT/'ejemplo_entrada.json').read_text(encoding='utf-8'))
    snapshot=request['snapshot']; answers=snapshot['answers']
    for q,ids in (overrides or {}).items():
        qa.answer(snapshot,q,ids)
    for _ in range(5):
        active=qa.branches(snapshot)
        for q in range(1,41):
            key=f'P{q:02d}'
            if q not in active:
                answers[key]=copy.deepcopy(EMPTY)
            elif answers[key]['state_code']=='not_shown':
                if q in qa.TEXT or active[q]=='optional':
                    answers[key]={**copy.deepcopy(EMPTY),'state_code':'omitted'}
                else:
                    qa.answer(snapshot,q,qa.DEFAULTS.get(q,[1]))
    if qa.has(snapshot,3,4):
        ids=medication or ['P03_M09']
        answers['P03_MICRO']={'option_ids':ids,'zone_ids':[],'state_code':qa.state(ids),'text':None}
    else:
        answers['P03_MICRO']=copy.deepcopy(EMPTY)
    return request

def main():
    from ejecutar import InputError,process_request
    checks=[]; coverage=[]
    def check(name,condition):
        if not condition:
            raise RuntimeError(name)
        checks.append(name)
    def compose_case(request):
        check('Validación sintética '+str(len(checks)),not qa.validate_input(request['snapshot']))
        result=process_request(request,composer,qa)
        check('Composición y conservación '+str(len(checks)),
              result['assessment_status']=='COMPLETE' and result['response_records']==request['snapshot']['answers']
              and result['production_delivery'] is False and result['output']['delivery_eligible'] is False)
        return result
    def reject(name,request):
        try:process_request(request,composer,qa)
        except InputError:check(name,True)
        else:check(name,False)
    contract=json.loads((ROOT/'contrato_instrumento_v4.json').read_text(encoding='utf-8'))
    for option in contract['option_labels']:
        q=int(option[1:3]);n=int(option[-2:])
        overrides={**ACTIVATE.get(q,{}),q:[n]}
        request=build_case(overrides)
        compose_case(request);coverage.append(option)
    for option in contract['medication_labels']:
        compose_case(build_case({3:[4]},[option]));coverage.append(option)
    for zone in contract['zone_labels']:
        request=build_case()
        request['snapshot']['answers']['P11']={'option_ids':[],'zone_ids':[zone],'state_code':'answered','text':None}
        compose_case(request);coverage.append(zone)
    check('272 alternativas ejecutadas',len(coverage)==272 and len(set(coverage))==272)
    # Verificar exclusiones y límites de cada múltiple.
    for q,maximum in qa.MULTI_MAX.items():
        reject(f'P{q:02d} máximo',build_case({**ACTIVATE.get(q,{}),q:list(range(1,maximum+2))}))
    for q,numbers in qa.EXCLUSIVE.items():
        for n in numbers:
            reject(f'P{q:02d} excluyente {n}',build_case({**ACTIVATE.get(q,{}),q:[1,n]}))
    for ids in (['P03_M01','P03_M09'],['P03_M09','P03_M10'],['P03_M10','P03_M08']):
        reject('Medicamentos excluyentes '+','.join(ids),build_case({3:[4]},ids))
    request=build_case({3:[4]},['P03_M01','P03_M08'])
    literal='  Nombre declarado <b>literal</b>\nSin inferir una causa.  '
    request['snapshot']['answers']['P03_MICRO']['text']=literal
    compose_case(request)
    obj=composer.compile_object(request['snapshot'])
    check('Medicamento literal',obj['literal_text']['P03_MICRO']==literal)
    check('Familias farmacológicas no generan hechos ni relaciones',
          not {i for f in obj['facts'].values() for i in f['evidence_ids']} & set(contract['medication_labels']))
    # Cada campo de texto recibe sus palabras en su propio registro.
    for q in sorted(qa.TEXT):
        request=build_case(ACTIVATE.get(q,{}))
        request['snapshot']['answers'][f'P{q:02d}']={**copy.deepcopy(EMPTY),'state_code':'answered','text':literal}
        compose_case(request)
        check('Texto literal P'+str(q),composer.compile_object(request['snapshot'])['literal_text'][f'P{q:02d}']==literal)
    # La nueva P08 no equivale a frecuencia nula ni dispara deseo responsivo.
    request=build_case({8:[6],9:[1]}); obj=composer.compile_object(request['snapshot'])
    check('Ausencia P08 distinta de Nunca',obj['facts']['desire_before']['category']=='not_observed'
          and not obj['flags']['responsive'] and 'no aparecen' not in obj['facts']['desire_before']['clause'])
    request=build_case({24:[17]});obj=composer.compile_object(request['snapshot'])
    check('P24 estado vigente e incertidumbre conservada',request['snapshot']['answers']['P24']['state_code']=='answered'
          and any(c['scope']=='P24' and c['evidence_ids']==['P24_O17'] for c in obj['uncertainty']))
    request['snapshot']['answers']['P24']['state_code']='dont_know';reject('Estado antiguo P24 rechazado',request)
    # Ramas y cambios de obligatoriedad concretos de la V4.
    for q,optional,necessary in [(28,{1:[5],24:[15]},{1:[5],24:[11]}),(29,{22:[9],24:[15]},{22:[9],24:[13]})]:
        request=build_case(optional);request['snapshot']['answers'][f'P{q}']={**copy.deepcopy(EMPTY),'state_code':'omitted'}
        compose_case(request)
        request=build_case(necessary);request['snapshot']['answers'][f'P{q}']={**copy.deepcopy(EMPTY),'state_code':'omitted'}
        reject(f'P{q} necesaria no admite omisión',request)
        check(f'P{q} doble vía una instancia',list(qa.branches(request['snapshot'])).count(q)==1)
    request=build_case({16:[5],17:[8],18:[1]});compose_case(request)
    check('P16_O05 abre P18 incluso con privacidad P17',18 in qa.branches(request['snapshot']))
    request=build_case({16:[4],17:[7],18:[1]});compose_case(request)
    request=build_case({16:[4],17:[3],18:[1]});qa.answer(request['snapshot'],16,[1]);reject('Cadena P17/P18 residual',request)
    request=build_case({19:[3],20:[9],24:[12]});check('P32 dos vías una instancia',list(qa.branches(request['snapshot'])).count(32)==1)
    request=build_case({10:[8]});check('Ausencia P10 no abre P12',12 not in qa.branches(request['snapshot']))
    request=build_case();del request['snapshot']['answers']['P03_MICRO'];reject('Registro P03_MICRO ausente rechazado',request)
    request=build_case({3:[4]});request['snapshot']['answers']['P03_MICRO']=copy.deepcopy(EMPTY);reject('Medicamento pendiente bloquea COMPLETE',request)
    request=build_case();request['snapshot']['answers']['P03_MICRO']={'option_ids':['P03_M01'],'zone_ids':[],'state_code':'answered','text':None};reject('Medicamento residual rechazado',request)
    request=build_case({3:[4]},['P03_M01']);request['snapshot']['answers']['P03_MICRO']['text']=literal;reject('Nombre sin Otro medicamento rechazado',request)
    for q in sorted(qa.CORE):
        request=build_case();request['snapshot']['answers'][f'P{q:02d}']={**copy.deepcopy(EMPTY),'state_code':'omitted'};reject('Núcleo necesario '+str(q),request)
    # Estados de privacidad permanecen distintos de answered.
    request=build_case({15:[9]});compose_case(request)
    request['snapshot']['answers']['P15']['state_code']='answered';reject('Privacidad no colapsada',request)
    regression=json.loads((ROOT/'pruebas_regresion.json').read_text(encoding='utf-8'))
    for row in regression:
        result=compose_case(row['request'])
        check('Composición anterior conservada '+row['case_id'],result['output']==row['expected_output'])
    for name in ['ejemplo_ausencia_p08_p24.json','ejemplo_medicamentos.json']:
        compose_case(json.loads((ROOT/name).read_text(encoding='utf-8')))
    report={'status':'V4_INPUT_COMPATIBILITY_PASS','checks':len(checks),'covered_alternatives':coverage,
            'questions':40,'records':41,'composition_regressions':len(regression),'production_delivery':False,
            'scope':'Contrato de entrada V4 y ejecución; la selección y redacción editoriales siguen en revisión. No prueba la interfaz desplegada.'}
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return report

if __name__=='__main__':
    try:main()
    except RuntimeError as exc:
        print(json.dumps({'status':'V4_INPUT_COMPATIBILITY_FAIL','check':str(exc)}),file=sys.stderr)
        raise SystemExit(1)
