"""Adversarial stress audit. Synthetic inputs only; no participant data.
The branch oracle below is independent of qa.branches and follows guide V4.
Run: python3 -X utf8 verificar_estres.py [--report PATH]
"""
import argparse
import collections
import copy
import itertools
import json
import random
import shutil
import tempfile
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'motor'))
import composer
import qa
from ejecutar import InputError, process_request, MAX_REQUEST_BYTES

EMPTY = {'option_ids': [], 'zone_ids': [], 'state_code': 'not_shown', 'text': None}
CORE = {1,2,6,8,9,10,13,14,15,16,19,21,22,24}
TEXT = {5,23,34,35,36,37,38,39,40}
LIMITS = {1:2,3:14,7:3,12:3,20:3,22:3,24:4,33:5}
EXCLUSIVE = {1:{7},3:{15,16},7:{15},12:{7,8},20:{11},22:{15,16},24:{15,17},33:{6,7,8}}
OPEN = {4:{1:[2]},5:{1:[2],4:[1]},7:{6:[1]},12:{10:[4]},17:{16:[4]},18:{16:[5],17:[3]},20:{19:[3]},25:{24:[4]},26:{24:[5]},27:{24:[6]},28:{24:[11]},29:{24:[13]},30:{24:[7]},31:{24:[9]},32:{24:[12]},33:{21:[4]},34:{1:[7]},35:{3:[14]},36:{22:[14]},37:{24:[16]},38:{6:[1],7:[14]},39:{19:[3],20:[10]},40:{21:[4],33:[5]}}
CONTRACT = json.loads((ROOT/'contrato_instrumento_v4.json').read_text(encoding='utf-8'))
BASE = json.loads((ROOT/'ejemplo_entrada.json').read_text(encoding='utf-8'))
OPTIONS = {q:sorted(i for i in CONTRACT['option_labels'] if i.startswith(f'P{q:02d}_')) for q in range(1,41)}


def branch_oracle(a):
    out = {q:('necessary' if q in CORE else 'optional') for q in CORE|{3,11,23}}
    def hit(q,*ns):
        return any(f'P{q:02d}_O{n:02d}' in a[f'P{q:02d}']['option_ids'] for n in ns)
    def add(q,condition,role='necessary'):
        if condition: out[q]=role
    add(4,hit(1,2,3,6),'optional');add(5,4 in out and hit(4,1),'optional')
    add(7,hit(6,1,2));add(12,hit(10,4,5,6))
    add(17,hit(16,3,4,5));add(18,hit(16,5) or (17 in out and hit(17,3,4,5,7)))
    add(20,hit(19,3,4,5));add(25,hit(24,4));add(26,hit(24,5));add(27,hit(24,6))
    add(28,hit(24,11) or hit(1,5),'necessary' if hit(24,11) else 'optional')
    add(29,hit(24,13) or hit(22,9),'necessary' if hit(24,13) else 'optional')
    add(30,hit(24,7));add(31,hit(24,9),'optional');add(32,hit(24,12) or (20 in out and hit(20,9)))
    add(33,hit(21,4,5));add(34,hit(1,7),'optional');add(35,hit(3,14),'optional')
    add(36,hit(22,14),'optional');add(37,hit(24,16),'optional')
    add(38,7 in out and hit(7,14),'optional');add(39,20 in out and hit(20,10),'optional')
    add(40,33 in out and hit(33,5),'optional')
    return out


def record(ids):
    return {'option_ids':list(ids),'zone_ids':[],
            'state_code':next((state for state in ('prefer_not_to_answer','not_clear','dont_know') if any(CONTRACT['state_by_option'].get(i)==state for i in ids)), 'answered'),'text':None}


def normalize(r):
    a=r['snapshot']['answers']
    for _ in range(6):
        active=branch_oracle(a)
        for q in range(1,41):
            key=f'P{q:02d}'
            if q not in active: a[key]=copy.deepcopy(EMPTY)
            elif a[key]['state_code']=='not_shown':
                a[key]=({**copy.deepcopy(EMPTY),'state_code':'omitted'} if q in TEXT or active[q]=='optional' else record([OPTIONS[q][0]]))
    if 'P03_O04' in a['P03']['option_ids']:
        if a['P03_MICRO']['state_code']=='not_shown':a['P03_MICRO']=record(['P03_M09'])
    else:a['P03_MICRO']=copy.deepcopy(EMPTY)
    return r


def case(overrides=None):
    r=copy.deepcopy(BASE)
    for q,ns in (overrides or {}).items():r['snapshot']['answers'][f'P{q:02d}']=record([f'P{q:02d}_O{n:02d}' for n in ns])
    return normalize(r)


def all_selections(q):
    concrete=[i for i in OPTIONS[q] if int(i[-2:]) not in EXCLUSIVE[q]]
    for size in range(1,min(LIMITS[q],len(concrete))+1):
        yield from itertools.combinations(concrete,size)
    for i in OPTIONS[q]:
        if i not in concrete:yield (i,)


def main(report_path=None):
    start=time.perf_counter();rng=random.Random(20261008)
    counts=collections.Counter();outcomes=collections.Counter();audit_errors=collections.Counter();checks=0
    def check(condition,label):
        nonlocal checks
        checks+=1
        if not condition:raise AssertionError(label)
    def run(r,group,order=False):
        before=copy.deepcopy(r)
        check(qa.branches(r['snapshot'])==branch_oracle(r['snapshot']['answers']),group+': branches differ from V4 oracle')
        check(not qa.validate_input(r['snapshot']),group+': valid case rejected')
        result=process_request(r,composer,qa);o=result['output'];counts[group]+=1;outcomes[o['status']]+=1
        audit_errors.update(o['contract_audit']['errors'])
        check(r==before,group+': input mutated')
        check(result['response_records']==r['snapshot']['answers'],group+': records changed')
        check(result['assessment_status']=='COMPLETE' and result['production_delivery'] is False and o['delivery_eligible'] is False,group+': delivery guard')
        check((o['status']=='RECOMPOSITION_REQUIRED')==bool(o['contract_audit']['errors']),group+': audit status')
        selected={i for a in r['snapshot']['answers'].values() for i in a['option_ids']+a['zone_ids']}
        used={i for t in o['claim_trace'] for i in t['evidence_ids']}|{i for g in o['name_evidence'] for i in g}
        private={i for a in r['snapshot']['answers'].values() if a['state_code']=='prefer_not_to_answer' for i in a['option_ids']}
        check(used<=selected and not used&private,group+': fabricated/private evidence')
        check('PRIVATE_TEST_SENTINEL' not in o['summary']+o['configuration_name'],group+': literal text interpreted')
        if order:
            other=copy.deepcopy(r)
            other['snapshot']['answers']=dict(reversed(list(other['snapshot']['answers'].items())))
            for a in other['snapshot']['answers'].values():a['option_ids'].reverse();a['zone_ids'].reverse()
            check(process_request(other,composer,qa)['output']==o,group+': order changed composition')
            counts['order_invariance_reexecutions']+=1
        return result
    def reject(r,label,code=None):
        try:process_request(r,composer,qa)
        except InputError as e:
            check(code is None or e.code==code,label+': wrong error code')
            check('PRIVATE_TEST_SENTINEL' not in str(e),label+': leaked text')
        else:check(False,label+': invalid input accepted')
        try:composer.compose_session(r)
        except ValueError as e:check('PRIVATE_TEST_SENTINEL' not in str(e),label+': unsafe direct API error')
        else:check(False,label+': direct API bypass')
        counts['invalid_api_cases']+=1
    def cli(raw,expected_code,label):
        p=subprocess.run([sys.executable,'-X','utf8',str(ROOT/'ejecutar.py')],input=raw,text=True,encoding='utf-8',capture_output=True,timeout=30)
        check(p.returncode==2 and not p.stdout,label+': CLI accepted/partial output')
        e=json.loads(p.stderr)
        check(e['code']==expected_code and e['production_delivery'] is False,label+': CLI code')
        check('PRIVATE_TEST_SENTINEL' not in p.stderr and 'Traceback' not in p.stderr,label+': error leaked data')
        counts['invalid_cli_cases']+=1

    # Enumerate every legal selection of each multiple independently, not the
    # whole 40-question Cartesian product. The reported distinction matters.
    for q in LIMITS:
        for ids in all_selections(q):
            r=case(OPEN.get(q,{}));r['snapshot']['answers'][f'P{q:02d}']=record(ids)
            run(normalize(r),f'exhaustive_selections_P{q:02d}')
    for size in range(1,9):
        for ids in itertools.combinations([f'P03_M{n:02d}' for n in range(1,9)],size):
            r=case({3:[4]});r['snapshot']['answers']['P03_MICRO']=record(ids);run(r,'exhaustive_medication_selections')
    for i in ['P03_M09','P03_M10']:
        r=case({3:[4]});r['snapshot']['answers']['P03_MICRO']=record([i]);run(r,'exhaustive_medication_selections')
    for size in range(1,10):
        for zones in itertools.combinations(CONTRACT['zone_labels'],size):
            r=case();r['snapshot']['answers']['P11']={'option_ids':[],'zone_ids':list(zones),'state_code':'answered','text':None};run(r,'exhaustive_zone_selections')
    for ids in all_selections(1):
        for i in OPTIONS[2]:
            r=case({1:[int(x[-2:]) for x in ids],2:[int(i[-2:])]})
            run(r,'P01_P02_complete_crossings')
            if ids==('P01_O07',):
                r['snapshot']['answers']['P34']={**copy.deepcopy(EMPTY),'state_code':'answered','text':'PRIVATE_TEST_SENTINEL en palabras propias'}
                result=run(r,'P01_P02_P34_literal_crossings')
                check(result['response_records']['P34']['text']==r['snapshot']['answers']['P34']['text'],'P34 literal preservation')
    # Each structurally valid care-branch combination exactly once. Hidden
    # child values are not counted as separate valid combinations.
    care_keys=set()
    for i in OPTIONS[16]:
        initial=case({16:[int(i[-2:])]})
        choices17=OPTIONS[17] if 17 in branch_oracle(initial['snapshot']['answers']) else [None]
        for j in choices17:
            overrides={16:[int(i[-2:])]}
            if j:overrides[17]=[int(j[-2:])]
            intermediate=case(overrides)
            choices18=OPTIONS[18] if 18 in branch_oracle(intermediate['snapshot']['answers']) else [None]
            for k in choices18:
                if k:overrides[18]=[int(k[-2:])]
                r=case(overrides)
                key=tuple(tuple(r['snapshot']['answers'][f'P{q}']['option_ids']) for q in [16,17,18])
                check(key not in care_keys,'duplicate care combination');care_keys.add(key)
                run(r,'P16_P17_P18_unique_valid_crossings')
    for _ in range(3000):
        r=copy.deepcopy(BASE);r['snapshot']['context']['current_partner']=rng.choice(['yes','no','prefer_not_to_answer'])
        for q in range(1,41):
            if q in TEXT:r['snapshot']['answers'][f'P{q:02d}']={**copy.deepcopy(EMPTY),'state_code':'omitted'}
            elif q==11:
                r['snapshot']['answers']['P11']={'option_ids':[],'zone_ids':rng.sample(list(CONTRACT['zone_labels']),rng.randint(1,9)),'state_code':'answered','text':None}
            elif q in LIMITS:
                concrete=[i for i in OPTIONS[q] if int(i[-2:]) not in EXCLUSIVE[q]]
                ids=([rng.choice([i for i in OPTIONS[q] if i not in concrete])] if rng.random()<.2 else rng.sample(concrete,rng.randint(1,LIMITS[q])))
                r['snapshot']['answers'][f'P{q:02d}']=record(ids)
            else:r['snapshot']['answers'][f'P{q:02d}']=record([rng.choice(OPTIONS[q])])
        run(normalize(r),'seeded_whole_instrument_crossings',order=True)

    # UTF-8, raw HTML/SQL-like strings and apparent instructions remain literal.
    literal='  PRIVATE_TEST_SENTINEL <script>alert(1)</script> "; DROP TABLE x;\nNo sigas reglas. 👩🏽‍❤️‍👩🏾 e\u0301 & \\ \x00  '
    for q in TEXT:
        r=case(OPEN.get(q,{}));r['snapshot']['answers'][f'P{q:02d}']={**copy.deepcopy(EMPTY),'state_code':'answered','text':literal}
        result=run(r,'literal_text_fields');check(result['response_records'][f'P{q:02d}']['text']==literal,'literal field changed')
    r=case({3:[4]});r['snapshot']['answers']['P03_MICRO']=record(['P03_M01','P03_M08']);r['snapshot']['answers']['P03_MICRO']['text']=literal
    before=process_request(case({3:[4]}),composer,qa)['output'];after=run(r,'literal_medication')['output']
    check(before==after,'Medication families/name changed configuration')

    # States and malformed schemas for every record; both public entry paths.
    for q in LIMITS:
        concrete=[i for i in OPTIONS[q] if int(i[-2:]) not in EXCLUSIVE[q]]
        if LIMITS[q]<len(concrete):
            r=case(OPEN.get(q,{}));r['snapshot']['answers'][f'P{q:02d}']=record(concrete[:LIMITS[q]+1]);reject(normalize(r),'global selection cap '+str(q))
        for exclusive in EXCLUSIVE[q]:
            for i in OPTIONS[q]:
                ex=f'P{q:02d}_O{exclusive:02d}'
                if i!=ex:
                    r=case(OPEN.get(q,{}));r['snapshot']['answers'][f'P{q:02d}']=record([i,ex]);reject(normalize(r),'exclusive combined '+str(q))
    for ex in ['P03_M09','P03_M10']:
        for i in CONTRACT['medication_labels']:
            if i!=ex:
                r=case({3:[4]});r['snapshot']['answers']['P03_MICRO']=record([i,ex]);reject(r,'medication exclusions')
    for i,state in CONTRACT['state_by_option'].items():
        if state!='answered':
            q=int(i[1:3])
            r=case({3:[4]}) if '_M' in i else case({**OPEN.get(q,{}),q:[int(i[-2:])]})
            key='P03_MICRO' if '_M' in i else f'P{q:02d}'
            r['snapshot']['answers'][key]['state_code']='answered';reject(r,'special state collapsed '+i)
    for key in BASE['snapshot']['answers']:
        for field,value in [('option_ids',None),('option_ids',['PRIVATE_TEST_SENTINEL']),('option_ids',[True]),('zone_ids',{}),('text',False),('state_code',[]),('state_code','PRIVATE_TEST_SENTINEL')]:
            r=copy.deepcopy(BASE);r['snapshot']['answers'][key][field]=value;reject(r,key+' '+field)
        for value in [None,[],False,'PRIVATE_TEST_SENTINEL']:
            r=copy.deepcopy(BASE);r['snapshot']['answers'][key]=value;reject(r,key+' record type')
    for q in set(range(1,41))-TEXT:
        r=case(OPEN.get(q,{}));r['snapshot']['answers'][f'P{q:02d}']['text']='';reject(r,'empty text forbidden '+str(q))
    for field,value in [('session_id','OTHER'),('rules_version','OTHER'),('instrument_version','OTHER'),('context',None),('context',{'current_partner':'PRIVATE_TEST_SENTINEL'})]:
        r=copy.deepcopy(BASE);r['snapshot'][field]=value;reject(r,'API '+field)
    for value in [float('nan'),float('inf'),float('-inf'),{'bad':('not','JSON')},{1:'nonstring key'},'\ud800','\udfff']:
        r=copy.deepcopy(BASE);r['metadata']=value;reject(r,'non JSON/Unicode metadata')
    r=copy.deepcopy(BASE);r['snapshot']['answers']['P23'].update(state_code='answered',text='\ud800PRIVATE_TEST_SENTINEL');reject(r,'Unicode literal',code='INVALID_UNICODE');cli(json.dumps(r),'INVALID_UNICODE','Unicode CLI')
    for q in TEXT:
        r=case(OPEN.get(q,{}));r['snapshot']['answers'][f'P{q:02d}'].update(state_code='omitted',text='  ');reject(r,'omitted text not null')
    for raw,code in [('{','INVALID_JSON'),('{"x":NaN}','NONSTANDARD_JSON_NUMBER'),('{"x":Infinity}','NONSTANDARD_JSON_NUMBER'),('{"x":1e999}','NONSTANDARD_JSON_NUMBER'),('{"x":0,"x":1}','DUPLICATE_JSON_KEY'),('{"outer":{"x":0,"x":1}}','DUPLICATE_JSON_KEY')]:cli(raw,code,'malformed JSON')
    nested=None
    for _ in range(70):nested=[nested]
    r=copy.deepcopy(BASE);r['extra']=nested;reject(r,'nesting limit',code='JSON_NESTING_LIMIT');cli(json.dumps(r),'JSON_NESTING_LIMIT','deep JSON')
    r=copy.deepcopy(BASE);r['extra']='x'*(MAX_REQUEST_BYTES+1);reject(r,'size limit',code='REQUEST_TOO_LARGE');cli(json.dumps(r),'REQUEST_TOO_LARGE','large JSON')

    # Stale-parent descendants must stay closed before validation is called.
    for overrides,closed in [({1:[1],4:[1]},5),({6:[3],7:[14]},38),({16:[1],17:[3]},18),({19:[1],20:[9]},32),({19:[1],20:[10]},39),({21:[1],33:[5]},40)]:
        r=case()
        for q,ns in overrides.items():r['snapshot']['answers'][f'P{q:02d}']=record([f'P{q:02d}_O{n:02d}' for n in ns])
        check(closed not in qa.branches(r['snapshot']),f'orphan opens P{closed}')
        reject(r,'residual parent '+str(closed))
    # Alternate parent activation remains available when another path closes.
    for r,q in [(case({16:[5],17:[8]}),18),(case({19:[1],24:[12]}),32),(case({1:[5],24:[11]}),28),(case({22:[9],24:[13]}),29)]:
        check(q in qa.branches(r['snapshot']),'alternate activation lost');run(r,'alternate_parent_paths')
    for q,optional,necessary in [(28,{1:[5],24:[15]},{1:[5],24:[11]}),(29,{22:[9],24:[15]},{22:[9],24:[13]})]:
        r=case(optional);r['snapshot']['answers'][f'P{q}']={**copy.deepcopy(EMPTY),'state_code':'omitted'};run(r,'optional_before_promotion')
        for parent,ns in necessary.items():r['snapshot']['answers'][f'P{parent:02d}']=record([f'P{parent:02d}_O{n:02d}' for n in ns])
        reject(r,'optional became necessary')
    p=subprocess.run([sys.executable,'-X','utf8',str(ROOT/'ejecutar.py'),'--PRIVATE_TEST_SENTINEL'],input='',text=True,encoding='utf-8',capture_output=True,timeout=30)
    check(p.returncode==2 and not p.stdout,'CLI invalid arguments')
    check(json.loads(p.stderr)['code']=='CLI_ARGUMENTS_INVALID','CLI argument error code')
    check('PRIVATE_TEST_SENTINEL' not in p.stderr and 'Traceback' not in p.stderr,'CLI argument leak')
    counts['invalid_cli_cases']+=1
    # Runtime integrity is checked on CLI startup, independently of the
    # manual verification command. These tests do not alter the real package.
    for filename in ['motor/canonical_options.json','motor/composition_catalog.json']:
        with tempfile.TemporaryDirectory(prefix='gozadoras_integrity_') as folder:
            isolated=Path(folder)/'package'
            shutil.copytree(ROOT,isolated,ignore=shutil.ignore_patterns('__pycache__'))
            with (isolated/filename).open('a',encoding='utf-8') as stream:stream.write(' ')
            p=subprocess.run([sys.executable,'-X','utf8',str(isolated/'ejecutar.py')],input=json.dumps(BASE),text=True,encoding='utf-8',capture_output=True,timeout=30)
            check(p.returncode==3 and not p.stdout,'modified asset must block execution')
            check(json.loads(p.stderr)['code']=='ENGINE_PACKAGE_INTEGRITY_ERROR','modified asset error')
            check('Traceback' not in p.stderr,'integrity safe error')
            counts['modified_asset_cli_cases']+=1
    check(not audit_errors,'Mechanical composition audit errors: '+str(dict(audit_errors)))
    report={'status':'ADVERSARIAL_STRESS_PASS','seed':20261008,'python_version':sys.version.split()[0],
            'checks':checks,'case_counts':dict(counts),'composition_status_counts':dict(outcomes),
            'composition_audit_errors':dict(audit_errors),'elapsed_seconds':round(time.perf_counter()-start,3),
            'production_delivery':False,
            'scope':'Exhaustive legal selections per multiple, medications and zones; full P01/P02 and unique valid P16/P17/P18 local crossings; 3000 seeded whole-instrument cases and 3000 reorderings. Not the exhaustive 40-question Cartesian product, load testing a web service, or editorial/user validation.'}
    if report_path:Path(report_path).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2));return report

if __name__=='__main__':
    if not sys.flags.utf8_mode:raise SystemExit(subprocess.run([sys.executable,'-X','utf8',str(Path(__file__).resolve()),*sys.argv[1:]]).returncode)
    p=argparse.ArgumentParser();p.add_argument('--report');args=p.parse_args()
    try:main(args.report)
    except Exception as e:
        print(json.dumps({'status':'ADVERSARIAL_STRESS_FAIL','check':str(e),'production_delivery':False}),file=sys.stderr)
        raise SystemExit(1)
