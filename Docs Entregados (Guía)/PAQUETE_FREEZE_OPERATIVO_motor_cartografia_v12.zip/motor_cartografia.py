#!/usr/bin/env python3
"""Motor de cartografía V12. FREEZE OPERATIVO hasta Filas. Python 3.10+."""
import argparse, collections, copy, hashlib, itertools, json, re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
RULE_VERSION = 'MOTOR-CARTOGRAFIA-12'
QMAP={};OPT={};READINGS=[];BLOCKS={};RULES={};CORE=set();ALWAYS=set()
TEXTQ={'P05','P23'} | {f'P{i:02}' for i in range(34,41)}
MULTI={'P01':(6,2,[7]),'P03':(14,14,[15,16]),'P07':(14,3,[15]),'P12':(6,3,[7,8]),'P20':(10,3,[11]),'P22':(14,3,[15,16]),'P24':(15,4,[15,17]),'P33':(5,5,[6,7,8]),'P03_MICRO':(8,8,[9,10])}
OMIT={'P03','P04','P05','P11','P23','P31'} | {f'P{i:02}' for i in range(34,41)}
CARE={'P16_O05','P17_O03','P17_O04','P18_O04','P33_O04'}
FRONT={'P13_O08','P14_O08','P30_O07','P16_O06','P17_O06'}
LAND_NAMES={1:'Mirador',2:'Manantial',3:'Sendero',4:'Clima',5:'Horizonte'}

def load_sources():
    global QMAP,OPT,READINGS,BLOCKS,RULES,CORE,ALWAYS
    c=json.loads((ROOT/'datos/catalogo.json').read_text(encoding='utf-8'))
    RULES=json.loads((ROOT/'datos/rules.json').read_text(encoding='utf-8'))
    if c['version']!=RULE_VERSION or RULES['version']!=RULE_VERSION:
        raise ValueError('Versiones de catálogo y reglas incompatibles')
    QMAP=c['questions'];OPT=c['options'];READINGS=c['readings'];BLOCKS=c['blocks']
    CORE=set(RULES['core_questions']);ALWAYS=CORE | {'P03','P11','P23'}


def clean(s):
    return re.sub(r'^[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ¿0-9]+', '', s).strip()

def sel(q,*nums):
    pref='P03_M' if q=='P03_MICRO' else q+'_O'
    return {'op':'selected_any','question':q,'ids':[pref+f'{n:02}' for n in nums]}

def AND(*x): return {'op':'all','args':list(x)}

def OR(*x): return {'op':'any','args':list(x)}

def NOT(x): return {'op':'not','arg':x}

def state(q,*s): return {'op':'state_any','question':q,'states':list(s)}

def count(q,n): return {'op':'selected_count_ge','question':q,'n':n}

def text(q): return {'op':'text_nonempty','question':q}

def zones(): return {'op':'zones_nonempty','question':'P11'}

def groups(q,gg): return {'op':'groups_ge','question':q,'groups':gg,'n':2}

def residual(ids): return {'op':'residual','exclude':ids}

def refs(p):
    return ({p['question']} if 'question' in p else set()) | set().union(*(refs(x) for x in p.get('args',[])),refs(p['arg']) if 'arg' in p else set())

def qstate(ids):
    labels=[OPT[i]['label'] for i in ids]
    if 'Prefiero no responder' in labels:return 'prefer_not_to_answer'
    if 'No sé' in labels:return 'dont_know'
    if 'No lo tengo claro' in labels:return 'not_clear'
    return 'answered'

def answer(q,ids=None,st=None,txt=None):
    if ids is None:ids=[]
    if isinstance(ids,int):ids=[ids]
    if ids and isinstance(ids[0],int):ids=[('P03_M' if q=='P03_MICRO' else q+'_O')+f'{i:02}' for i in ids]
    return {'question_id':q,'option_ids':[i for i in ids if not i.startswith('Z')],
            'zone_ids':[i for i in ids if i.startswith('Z')],
            'state_code':st or ('answered' if txt is not None else qstate(ids)), 'text':txt or ''}

def yes(s,q,*nums):
    return bool(set(sel(q,*nums)['ids']) & set(s.get(q,{}).get('option_ids',[]))) and s.get(q,{}).get('state_code') not in {'not_shown','omitted'}

def active(s,q):
    if q in ALWAYS:return True
    if q=='P03_MICRO':return yes(s,'P03',4)
    cond={
      'P04':lambda:yes(s,'P01',2,3,6),'P05':lambda:yes(s,'P04',1),'P07':lambda:yes(s,'P06',1,2),
      'P12':lambda:yes(s,'P10',4,5,6),'P17':lambda:yes(s,'P16',3,4,5),
      'P18':lambda:yes(s,'P16',5) or yes(s,'P17',3,4,5,7),
      'P20':lambda:yes(s,'P19',3,4,5),
      'P25':lambda:yes(s,'P24',4),'P26':lambda:yes(s,'P24',5),'P27':lambda:yes(s,'P24',6),
      'P28':lambda:yes(s,'P01',5) or yes(s,'P24',11),
      'P29':lambda:yes(s,'P22',9) or yes(s,'P24',13),'P30':lambda:yes(s,'P24',7),
      'P31':lambda:yes(s,'P24',9),'P32':lambda:yes(s,'P20',9) or yes(s,'P24',12),
      'P33':lambda:yes(s,'P21',4,5),'P34':lambda:yes(s,'P01',7),'P35':lambda:yes(s,'P03',14),
      'P36':lambda:yes(s,'P22',14),'P37':lambda:yes(s,'P24',16),'P38':lambda:yes(s,'P07',14),
      'P39':lambda:yes(s,'P20',10),'P40':lambda:yes(s,'P33',5)}
    return cond[q]()

def omissible(s,q):
    return q in OMIT or (q=='P28' and not yes(s,'P24',11)) or (q=='P29' and not yes(s,'P24',13))

def parents(s,forced):
    # Solo completa precondiciones no especificadas. Nunca pisa un padre explícito.
    def setq(q,n):
        if q not in forced:s[q]=answer(q,n)
    for q in sorted(forced,reverse=True):
        if s[q]['state_code']=='not_shown':continue
        if q=='P03_MICRO':setq('P03',4)
        if q in {'P04','P05'}:setq('P01',2)
        if q=='P05':setq('P04',1)
        if q in {'P07','P38'}:setq('P06',1)
        if q=='P38':setq('P07',14)
        if q=='P12':setq('P10',4)
        if q in {'P17','P18'}:setq('P16',5 if q=='P18' else 4)
        if q in {'P20','P39'}:setq('P19',4)
        if q=='P39':setq('P20',10)
        if q in {'P25','P26','P27','P28','P29','P30','P31','P32','P37'}:
            dest={'P25':4,'P26':5,'P27':6,'P28':11,'P29':13,'P30':7,'P31':9,'P32':12,'P37':16}[q]
            if not active(s,q):setq('P24',dest)
        if q in {'P33','P40'}:setq('P21',4)
        if q=='P40':setq('P33',5)
        if q=='P34':setq('P01',7)
        if q=='P35':setq('P03',14)
        if q=='P36':setq('P22',14)

def make_snapshot(forced=None):
    forced=forced or {}
    defaults={'P01':1,'P02':2,'P06':3,'P08':3,'P09':3,'P10':2,'P13':2,'P14':2,'P15':2,'P16':1,'P19':1,'P21':2,'P22':1,'P24':15}
    s={q:answer(q,defaults.get(q,1)) for q in QMAP if q not in TEXTQ and q not in {'P03','P11'}}
    for q in OMIT:s[q]=answer(q,st='omitted')
    s.update(forced); parents(s,forced)
    # Orden topológico real: profundizaciones tras Horizonte. P33 antes de P40.
    order=['P01','P02','P03','P03_MICRO']+[f'P{i:02}' for i in range(4,41)]
    for q in order:
        is_active=active(s,q)
        if not is_active:
            if q in forced and forced[q]['state_code']!='not_shown':raise ValueError('Branch inválido '+q)
            s[q]=answer(q,st='not_shown')
        elif s.get(q,{}).get('state_code')=='not_shown':
            if q in forced:raise ValueError('Pregunta activa marcada not_shown '+q)
            s[q]=answer(q,st='omitted') if omissible(s,q) else answer(q,1)
        elif q not in s:s[q]=answer(q,st='omitted') if omissible(s,q) else answer(q,1)
    validate(s)
    return s

def evalp(p,s,matches):
    op=p['op'];a=s.get(p.get('question'),{}); valid=a.get('state_code') not in {'not_shown','omitted',None}
    if op=='selected_any':return valid and bool(set(a.get('option_ids',[])) & set(p['ids']))
    if op=='all':return all(evalp(x,s,matches) for x in p['args'])
    if op=='any':return any(evalp(x,s,matches) for x in p['args'])
    if op=='not':return not evalp(p['arg'],s,matches)
    if op=='state_any':return a.get('state_code') in p['states']
    if op=='selected_count_ge':return valid and len(a['option_ids'])>=p['n']
    if op=='text_nonempty':return valid and bool(a.get('text','').strip())
    if op=='zones_nonempty':return valid and bool(a.get('zone_ids'))
    if op=='groups_ge':return valid and sum(bool(set(a['option_ids'])&set(g)) for g in p['groups'])>=p['n']
    if op=='manual':return False
    if op=='residual':return not (set(p['exclude'])&matches)
    raise ValueError(op)

def match_readings(s):
    found=set()
    for r in READINGS:
        if evalp(r['predicate'],s,found):found.add(r['id'])
    return sorted(found)

def is_uncert(oid):return OPT[oid]['label'] in {'No sé','No lo tengo claro'}

def landmap():
    lm=collections.defaultdict(set)
    for b in BLOCKS.values():
        for q in b['questions']:lm[q].add(LAND_NAMES[int(b['id'][0])])
    lm['P03_MICRO']=set(lm['P03'])  # Definición explícita C3 del paquete v11/v10.
    return lm

def _signals(s,incoming_tensions=None,extra_load_channels=None):
    validate(s)
    trace=[];weights=[];boosts=[];floors=[];review=[]; flags=collections.defaultdict(list)
    lm=landmap(); uncertainty=[];pref=[];channels={}
    tensions,detector_review=detect(s);review.extend(detector_review)
    for t in incoming_tensions or []:
        ids=t.get('option_ids',[])
        valid=ids and all(i in OPT and i in s[OPT[i]['question']]['option_ids'] for i in ids)
        if not valid:
            review.append({'detector':t.get('detector'),'reason':'Traza entrante sin ancla vigente'});continue
        if t.get('detector')=='CP-08':
            review.append({'detector':'CP-08','reason':'Detector apagado; solo traza.'})
            tensions.append(dict(t,weight=0,disabled=True))
        elif not any(t.get('detector')==z['detector'] and set(ids)==set(z['option_ids']) for z in tensions):
            review.append({'detector':t.get('detector'),'reason':'Traza entrante no coincide con un detector canónico'} )
    for q in sorted(s,key=qorder):
        a=s[q]
        st=a['state_code']
        if st=='not_shown':trace.append({'question':q,'state':st,'route':'C7','weight':None});continue
        if st=='omitted':trace.append({'question':q,'state':st,'route':'C6','weight':None});continue
        flags['SEÑAL_PRESENTADA'].append(q)
        if st=='answered':flags['SEÑAL_ANSWERED'].append(q)
        if q in MULTI and set(a['option_ids']) & set(sel(q,*MULTI[q][2])['ids']):flags['EXCLUYENTE'].append(q)
        if q=='P11' and a['option_ids']:flags['EXCLUYENTE'].append(q)
        if q in {'P03','P07','P20','P33'} and len(a['option_ids'])>1:flags['MULTI_INTRA_CANAL'].append(q)
        if q=='P03_MICRO':flags['MICRO_MEDICAMENTO'].append(q)
        if q=='P01' and len(a['option_ids'])==2:flags['DOBLE_SITUACION'].append(q)
        for oid in a['option_ids']:
            label=OPT[oid]['label'];route='HUE';w=None
            if label=='Prefiero no responder':
                route='C4';w=2;pref.append((q,oid));flags['PRIVACIDAD'].append(oid)
                trace.append({'question':q,'option_id':oid,'route':'C4 contenido','weight':0,'literal':OPT[oid]['literal']})
            elif is_uncert(oid):route='C2';w=1;uncertainty.append((q,oid));flags['INCERTIDUMBRE'].append(oid)
            elif oid in CARE:route='C12';flags['CUIDADO'].append(oid)
            elif label=='Depende':route='SIN_CLASIFICAR'
            elif oid in FRONT:route='FRONTERA'
            elif q in {'P02','P13','P14'} and int(oid[-2:])<=5:
                route='C10';w=3 if int(oid[-2:])>=4 else 2
            elif oid in RULES['c8_external_option_map']:
                e=RULES['c8_external_option_map'][oid]
                route='C8';w=e['w'];flags['SEMANTICO_EXTERNO'].append(oid)
                if e['stop_scale']:flags['FRENO_ESCALA'].append(oid)
            elif q=='P01' and len(a['option_ids'])==2:route='C13';w=3
            elif oid=='P01_O07':route='C14';w=2
            elif q=='P03_MICRO' and int(oid[-2:])<=8:route='C31';w=2
            elif q in {'P07','P20','P33'} and int(oid[-2:])<=({'P07':14,'P20':10,'P33':5}[q]):
                route='C16';channels.setdefault(q,[]).append(oid)
            if oid in CARE and q=='P33':channels.setdefault(q,[]).append(oid)
            record={'question':q,'option_id':oid,'literal':OPT[oid]['literal'],'state':st,'route':route,'weight':w}
            trace.append(record)
            if w is not None:weights.append(record)
        if a['zone_ids']:
            record={'question':q,'zone_ids':a['zone_ids'],'route':'C32','weight':2};trace.append(record);weights.append(record)
        # Other sélection without detail is kept; boost anchors literal Other, not invented prose.
        others=[i for i in a['option_ids'] if OPT[i]['label'] in {'Otro','Otra','Otra cosa','Otro medicamento'}]
        if a['text'].strip() or others:flags['VERSION_PROPIA'].append({'question':q,'option_ids':others,'text':a['text']})
    for q,ids in channels.items():
        record={'question':q,'option_ids':ids,'route':'C16','weight':2};trace.append(record);weights.append(record)
    # Canales abiertos ya tipados por el filtro: validación de anclas antes de agregarlos.
    for item in extra_load_channels or []:
        q=item['question'];ids=item['option_ids']
        if q not in s or q in {'P03','P03_MICRO'} or not ids or not set(ids).issubset(s[q]['option_ids']) or s[q]['state_code'] in {'not_shown','omitted'}:
            review.append({'question':q,'reason':'Canal externo sin ancla o P03 excluido'});continue
        channels.setdefault(q,[]).extend(ids)
        if not any(w['question']==q and w['route']=='C16' for w in weights):
            record={'question':q,'option_ids':ids,'route':'C16','weight':2};trace.append(record);weights.append(record)
    for q in channels:channels[q]=sorted(set(channels[q]))
    if flags['VERSION_PROPIA']:boosts.append({'rule':'C15','grade':3,'anchors':flags['VERSION_PROPIA'],'outside_max':True})
    byland=collections.defaultdict(set)
    for q,oid in uncertainty:
        for name in lm[q]:byland[name].add(oid)
    # Contar IDs únicos por paisaje. P03 pertenece a dos, sin multiplicar la misma respuesta.
    distinct_three=False
    if len(uncertainty)>=3:
        for trio in itertools.combinations(uncertainty,3):
            if any(len(set(assignment))==3 for assignment in itertools.product(*(sorted(lm[q]) for q,_ in trio))):
                distinct_three=True;break
    if distinct_three or any(len(x)>=2 for x in byland.values()):
        boosts.append({'rule':'C3','grade':3,'anchors':[o for _,o in uncertainty],'outside_max':True})
    k=len(channels)
    if k>=2:boosts.append({'rule':'C17','grade':min(k-1,3),'K':k,'anchors':channels,'outside_max':True})
    if flags['CUIDADO']:floors.append({'rule':'C12','type':'w4-CUIDADO','anchors':flags['CUIDADO']})
    carepref=[o for q,o in pref if q in {'P16','P17','P18','P33'}]
    if len(carepref)>=2:floors.append({'rule':'C34','type':'w4-DEFERENCIA-PREFIERO','anchors':carepref})
    otherpref=[o for q,o in pref if q not in {'P16','P17','P18','P33'}]
    if len(otherpref)>=2:flags['PRIVACIDAD_CONJUNTO']=otherpref
    if s['P12']['state_code']!='not_shown':floors.append({'rule':'C38','type':'w4-RELEVANCIA-P12','anchors':s['P12']['option_ids'],'branch_anchor':s['P10']['option_ids'],'substantive_ids':[o for o in s['P12']['option_ids'] if int(o[-2:])<=6]})
    operative=[t for t in tensions if not t.get('disabled')]
    if operative:boosts.append({'rule':'C19','grade':3,'anchors':operative,'outside_max':True})
    for t in tensions:t['weight']=0
    assert len([b for b in boosts if b['rule']=='C19'])<=1
    assert all(w['route'] not in {'C15','C17'} for w in weights)
    assert k==len(channels) and 'P03' not in channels
    matched=match_readings(s)
    return {'rules_version':RULE_VERSION,'mode':'MOTOR_OPERATIVO','product_enabled':False,
      'situated_core':[{'question':q,'presented':True,'presentation_priority':'S-01','weight_from_core_statute':None} for q in sorted(CORE)],
      'readings':matched,'trace':trace,'individual_weights':weights,'max_individual':max([w['weight'] for w in weights],default=None),
      'boosts':boosts,'floors':floors,'tensions':tensions,'flags':dict(flags),'load_channels':channels,
      'review_required':review,'gate_complete':True,
      'ordering':'C12 cuidado >= C34 deferencia; C38 relevancia; boosts coexistentes; señales individuales',
      'total_order_defined':True}

def domain(q):
    if q in TEXTQ:
        yield answer(q,txt='Texto de prueba conservado literalmente.');yield answer(q,st='omitted');return
    if q=='P11':
        for n in range(1,10):
            for ids in itertools.combinations([f'Z{i:02}' for i in range(1,10)],n):yield answer(q,list(ids))
        for i in range(1,4):yield answer(q,i)
    elif q in MULTI:
        n,mx,ex=MULTI[q]
        options=list(range(1,n+1))
        if q=='P24':options=[*range(1,15),16]
        for c in range(1,mx+1):
            for ids in itertools.combinations(options,c):yield answer(q,list(ids))
        for i in ex:yield answer(q,i)
    else:
        for oid in OPT:
            if OPT[oid]['question']==q and not oid.startswith('Z'):yield answer(q,[oid])
    if q in OMIT or q in {'P28','P29'}:yield answer(q,st='omitted')

def qorder(q):
    return (3,1) if q=='P03_MICRO' else (int(q[1:]),0)


def validate(s):
    if not isinstance(s,dict) or set(s)!=set(QMAP):
        raise ValueError('La entrada debe conservar las 40 preguntas y el estado de la microprofundización')
    for q,a in s.items():
        if not isinstance(a,dict):raise ValueError('Respuesta sin estructura '+q)
        required={'question_id','option_ids','zone_ids','state_code','text'}
        if not required.issubset(a) or a['question_id']!=q:raise ValueError('Campos de respuesta inválidos '+q)
        ids=a['option_ids'];zs=a['zone_ids'];st=a['state_code'];txt=a['text']
        if not isinstance(ids,list) or not isinstance(zs,list) or not all(isinstance(i,str) for i in ids+zs) or not isinstance(txt,str):raise ValueError('Tipos de respuesta inválidos '+q)
        if st not in {'answered','dont_know','not_clear','prefer_not_to_answer','omitted','not_shown'}:raise ValueError('Estado desconocido '+q)
        if len(ids+zs)!=len(set(ids+zs)):raise ValueError('ID duplicado '+q)
        if any(i not in OPT or OPT[i]['question']!=q for i in ids+zs):raise ValueError('ID ajeno a la pregunta '+q)
        if any(i.startswith('Z') for i in ids) or any(not i.startswith('Z') for i in zs):raise ValueError('Separar opciones de zonas '+q)
        if q!='P11' and zs:raise ValueError('Zonas fuera de P11')
        if st=='not_shown':
            if active(s,q) or ids or zs or txt:raise ValueError('Ausencia estructural inválida '+q)
            continue
        if not active(s,q):raise ValueError('Respuesta huérfana '+q)
        if st=='omitted':
            if not omissible(s,q) or ids or zs or txt:raise ValueError('Omisión no autorizada '+q)
            continue
        if q in TEXTQ:
            if st!='answered' or ids or zs or not txt.strip():raise ValueError('Texto inválido '+q)
            continue
        if txt and not (q=='P03_MICRO' and 'P03_M08' in ids):raise ValueError('Texto sin campo autorizado '+q)
        if q=='P11':
            if not ids and not zs:raise ValueError('P11 vacía')
            if ids and (zs or len(ids)!=1):raise ValueError('Externas de P11 excluyentes')
        elif q in MULTI:
            _,mx,ex=MULTI[q]
            if not 1<=len(ids)<=mx:raise ValueError('Cardinalidad '+q)
            if set(ids)&set(sel(q,*ex)['ids']) and len(ids)>1:raise ValueError('Excluyentes '+q)
        elif len(ids)!=1:raise ValueError('Selección única '+q)
        if st!=qstate(ids):raise ValueError('Estado no corresponde al literal '+q)
    return True


def evidence(p,s):
    """Only the selected options that actually make this criterion true."""
    op=p['op']
    if op=='selected_any':return sorted(set(s[p['question']]['option_ids'])&set(p['ids']))
    if op=='all':return sorted(set().union(*(set(evidence(x,s)) for x in p['args'])))
    if op=='any':return sorted(set().union(*(set(evidence(x,s)) for x in p['args'] if evalp(x,s,set()))))
    return []


def detect(s):
    out=[]
    for d in RULES['tension_detectors']:
        if d['enabled'] and evalp(d['criterion'],s,set()):
            ids=evidence(d['criterion'],s)
            qs=sorted({OPT[i]['question'] for i in ids},key=qorder)
            out.append({'detector':d['id'],'questions':qs,'option_ids':ids,'weight':0,'meaning':d['meaning']})
    return out,[]


def _anchor_questions(item):
    if isinstance(item,str):return {OPT[item]['question']} if item in OPT else set()
    if isinstance(item,list):return set().union(*(_anchor_questions(i) for i in item))
    if isinstance(item,dict):
        found={item['question']} if item.get('question') in QMAP else set()
        for key,v in item.items():
            if key in QMAP:found.add(key)
            if key!='text':found |= _anchor_questions(v)
        return found
    return set()


def situated_group(q,s):
    if q in CORE:return 'NUCLEO'
    if q=='P28':return 'CONDICIONAL_NECESARIA' if yes(s,'P24',11) else 'ENRIQUECEDORA_OPCIONAL_ACLARACION'
    if q=='P29':return 'CONDICIONAL_NECESARIA' if yes(s,'P24',13) else 'ENRIQUECEDORA_OPCIONAL_ACLARACION'
    if 'NECESARIA' in QMAP[q]['statute']:return 'CONDICIONAL_NECESARIA'
    return 'ENRIQUECEDORA_OPCIONAL_ACLARACION'


def compose_rows(s,r,session_id):
    """One source question per literal row. Added rows never consume its weight again."""
    rows=[];ranking={g:i for i,g in enumerate(RULES['row_order'])}
    shown=[q for q in QMAP if s[q]['state_code']!='not_shown']
    ordered=sorted(shown,key=lambda q:(ranking[situated_group(q,s)],qorder(q)))
    positions={q:n for n,q in enumerate(ordered,1)}
    matches={z['id']:z for z in READINGS if z['id'] in r['readings']}
    snapshot_state='REVIEW_REQUIRED' if r['review_required'] else 'operativo'
    def label_ids(qs):
        return [rid for rid,z in matches.items() if set(z['questions'])&set(qs)]
    def mk(rid,kind,qs,anchors,literal):
        labels=label_ids(qs)
        floors=[f for f in r['floors'] if f['rule'] in {'C12','C34'} or set(qs)&_anchor_questions(f)]
        boosts=[b for b in r['boosts'] if set(qs)&_anchor_questions(b['anchors'])]
        refs_t=[t['id_tension'] for t in r['tensions'] if set(qs)&set(t['questions'])]
        words=[]
        if any(f['rule']=='C12' for f in floors):words.append('Cuidado primero; conservar literales y no inferir daño o causas')
        if any(f['rule']=='C34' for f in floors):words.append('Respetar la reserva sin indagar')
        if any(f['rule']=='C38' for f in floors):words.append('Dar relevancia a P12 por su presentación, sin inferir función psicológica')
        if refs_t:words.append('Conservar los polos de la tensión sin elegir uno')
        if kind=='voz_propia':words.append('Conservar el texto exacto; no interpretar ni reformular')
        if kind=='estado':words.append('Omisión válida; no convertirla en experiencia declarada')
        if not words:words.append('Conservar qué declaró y su grado; no inventar causas')
        return {'fila_id':f'{session_id}:{rid}','tipo_fila':kind,'preguntas':qs,
         'grupo_situado':situated_group(qs[0],s) if kind in {'respuesta','estado','voz_propia'} else 'CONJUNTO_ANCLADO',
         'orden_base':min(positions[q] for q in qs),'ancla':anchors,'trazabilidad':'completa','literal':literal,
         'senal_w':[],'pisos':floors,'boosts':boosts,'tension_ref':refs_t,
         'regla_lenguaje':words,'etiqueta_cartografia':labels or ['por mapear'],
         'titulos_base':[matches[k]['title'] for k in labels],
         'estado_snapshot':snapshot_state,'destino_producto':{'filas_outcome':snapshot_state=='operativo','final_producto':False},
         'version_reglas':RULE_VERSION}
    for q in ordered:
        a=s[q];st=a['state_code'];ids=sorted(a['option_ids']);zones=sorted(a['zone_ids'])
        kind='estado' if st=='omitted' else ('voz_propia' if q in TEXTQ else 'respuesta')
        anchor={'question_id':q,'question_text':QMAP[q]['question'],'state_code':st,'option_ids':ids,'zone_ids':zones,
                'option_literals':[OPT[i]['literal'] for i in ids],'zone_literals':[OPT[i]['literal'] for i in zones]}
        literal=a['text'] if kind=='voz_propia' else ('OMITIDO' if kind=='estado' else [OPT[i]['literal'] for i in ids+zones])
        row=mk(q+':'+kind,kind,[q],anchor,literal)
        row['senal_w']=[w for w in r['trace'] if w.get('question')==q]
        rows.append(row)
        if q=='P03_MICRO' and a['text'].strip():
            voice=mk(q+':voz_propia','voz_propia',[q],{'question_id':q,'field_id':'P03_M_OTHER_TEXT','trigger_option':'P03_M08'},a['text'])
            rows.append(voice)
    for t in r['tensions']:
        row=mk(t['id_tension'],'tensión',t['questions'],t,t.get('meaning','Traza retenida; detector apagado'))
        row['tension_ref']=[t['id_tension']];row['senal_w']=[{'route':'0_solo_traza','weight':0}]
        rows.append(row)
    for b in r['boosts']:
        if b['rule'] not in {'C3','C17'}:continue
        qs=sorted(_anchor_questions(b['anchors']),key=qorder)
        row=mk(b['rule']+':conjunto','conjunto',qs,b,[])
        row['boosts']=[b]
        row['regla_lenguaje'].append('Nombrar coexistencia de cargas sin inferir gravedad' if b['rule']=='C17' else 'Nombrar incertidumbre compartida sin exigir claridad')
        rows.append(row)
    rows.sort(key=lambda row:(row['orden_base'],0 if row['tipo_fila'] in {'respuesta','estado','voz_propia'} else 1,row['fila_id']))
    for i,row in enumerate(rows,1):row['orden_fila']=i
    def lang_key(row):
        qs=set(row['preguntas'])
        if qs & set().union(*(_anchor_questions(f['anchors']) for f in r['floors'] if f['rule']=='C12')):priority=0
        elif qs & set().union(*(_anchor_questions(f['anchors']) for f in r['floors'] if f['rule']=='C34')):priority=1
        elif 'P12' in qs and any(f['rule']=='C38' for f in r['floors']):priority=2
        elif row['tipo_fila']=='tensión':priority=3
        elif row['tipo_fila']=='voz_propia':priority=4
        elif row['tipo_fila']=='conjunto' and any(b['rule']=='C17' for b in row['boosts']):priority=5
        elif row['tipo_fila']=='conjunto':priority=6
        else:priority=7
        return priority,row['orden_base'],row['fila_id']
    plan=sorted(rows,key=lang_key)
    for i,row in enumerate(plan,1):row['orden_lenguaje']=i
    return rows,{'pisos_que_gobiernan':r['floors'],'orden_referencias':[row['fila_id'] for row in plan],
                 'boosts_no_se_vuelven_a_sumar':True,'max_individual':r['max_individual'],
                 'titulo_configuracion_completa':None,'prosa_final':None}


def run(s,incoming_tensions=None,extra_load_channels=None,session_id='SINTETICO'):
    # Never modify a supplied answer or replace a missing answer with a default.
    original=copy.deepcopy(s)
    validate(s)
    r=_signals(s,incoming_tensions,extra_load_channels)
    # Canonical one-per-detector closing registry. Exact evidence, no broad unrelated poles.
    for t in r['tensions']:
        t.setdefault('questions',sorted({OPT[i]['question'] for i in t['option_ids']},key=qorder))
        t['id_tension']=t['detector']
        t['trazabilidad']='completa';t['trabajo']=['puente','cierre'];t['version_capa']=RULE_VERSION
    if len({t['id_tension'] for t in r['tensions']})!=len(r['tensions']):
        r['review_required'].append({'reason':'Detector duplicado en registro de tensiones'})
    rows,plan=compose_rows(s,r,session_id)
    r.update({'estado_snapshot':'REVIEW_REQUIRED' if r['review_required'] else 'operativo',
              'filas':rows,'plan_lenguaje':plan,'filas_outcome_enabled':not bool(r['review_required']),
              'product_final':False,'session_id':session_id,'instrument_version':RULES['instrument_version'],
              'gate_complete':True,'assert_P_S4':len([b for b in r['boosts'] if b['rule']=='C19'])<=1,
              'ordering':'orden_base por Situado; orden_lenguaje por pisos y H1 H8; desempate por pregunta y fila'})
    assert s==original
    return r


def process(data):
    """Production-facing entry point. Rejected inputs return a structured blocked result."""
    try:
        if not isinstance(data,dict):raise ValueError('Entrada no es un objeto')
        if data.get('instrument_version')!=RULES['instrument_version']:raise ValueError('Versión del instrumento incompatible; aplicar migración explícita')
        if data.get('rules_version')!=RULE_VERSION:raise ValueError('Versión de reglas incompatible')
        if not isinstance(data.get('session_id'),str) or not data['session_id'].strip():raise ValueError('Falta session_id')
        if not isinstance(data.get('application_date'),str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}(?:T.+)?',data['application_date']):raise ValueError('Falta fecha de aplicación en formato ISO')
        for k in ['incoming_tensions','extra_load_channels']:
            if not isinstance(data.get(k,[]),list) or any(not isinstance(x,dict) for x in data.get(k,[])):raise ValueError('Lista inválida '+k)
        return run(data['snapshot'],data.get('incoming_tensions'),data.get('extra_load_channels'),data['session_id'])
    except (ValueError,KeyError,TypeError,AttributeError) as e:
        return {'rules_version':RULE_VERSION,'estado_snapshot':'REVIEW_REQUIRED','filas_outcome_enabled':False,
                'product_final':False,'gate_complete':False,'filas':[],
                'review_required':[{'reason':str(e)}],'input_preserved':True}


def main():
    p=argparse.ArgumentParser(description='Motor de cartografía V12 hasta Filas')
    p.add_argument('--entrada',required=True);p.add_argument('--salida')
    a=p.parse_args();load_sources()
    try:data=json.loads(Path(a.entrada).read_text(encoding='utf-8'))
    except (ValueError,OSError) as e:
        result={'estado_snapshot':'REVIEW_REQUIRED','filas_outcome_enabled':False,'filas':[], 'review_required':[{'reason':str(e)}]}
    else:result=process(data)
    encoded=json.dumps(result,ensure_ascii=False,indent=2)
    if a.salida:Path(a.salida).write_text(encoded,encoding='utf-8')
    else:print(encoded)
    return 0 if result['estado_snapshot']=='operativo' else 2

if __name__=='__main__':sys.exit(main())
