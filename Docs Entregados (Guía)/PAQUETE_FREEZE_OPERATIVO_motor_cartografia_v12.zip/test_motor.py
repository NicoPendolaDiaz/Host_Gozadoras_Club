"""Pruebas funcionales de integración y fronteras del contrato V12."""
import copy, itertools, json, unittest
import motor_cartografia as m

class MotorTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):m.load_sources()
 def result(self,f=None):return m.run(m.make_snapshot(f))
 def hascp(self,r,cp):return any(t['detector']==cp for t in r['tensions'])
 def boost(self,r,rule):return [b for b in r['boosts'] if b['rule']==rule]
 def invalid(self,f):
  with self.assertRaises(ValueError):m.make_snapshot(f)
 def test_01_determinismo_y_orden_entrada(self):
  s=m.make_snapshot();self.assertEqual(m.run(s),m.run(dict(reversed(list(s.items())))))
 def test_02_no_modifica_texto(self):
  t='  <b>Yo & mi deseo</b>\n No interpretar.  '
  s=m.make_snapshot({'P23':m.answer('P23',txt=t)});old=copy.deepcopy(s);r=m.run(s)
  self.assertEqual(old,s);self.assertEqual(next(f['literal'] for f in r['filas'] if f['preguntas']==['P23']),t)
 def test_03_c15_fuera_max(self):
  self.assertEqual(self.result()['max_individual'],self.result({'P23':m.answer('P23',txt='Mis palabras')})['max_individual'])
 def test_04_c32_numero_zonas_no_severidad(self):
  for n in [1,4,9]:
   r=self.result({'P11':m.answer('P11',[f'Z{i:02}' for i in range(1,n+1)])})
   self.assertEqual([w['weight'] for w in r['individual_weights'] if w['route']=='C32'],[2])
 def test_05_ausencia_c8_todas_opciones(self):
  for q,n in [('P08',6),('P10',8),('P15',7)]:
   r=self.result({q:m.answer(q,n)});self.assertFalse(r['review_required'])
   self.assertEqual(next(t['weight'] for t in r['trace'] if t.get('option_id')==f'{q}_O{n:02}'),1)
   self.assertFalse(self.hascp(r,'CP-03'))
 def test_06_ausencia_no_es_poco_deseo(self):
  r=self.result({'P08':m.answer('P08',6),'P09':m.answer('P09',1),'P10':m.answer('P10',8)})
  self.assertIn('2.3.08',r['readings']);self.assertNotIn('2.3.04',r['readings'])
 def test_07_externas_mapa_completo(self):
  for oid,v in m.RULES['c8_external_option_map'].items():
   q=oid[:3];r=self.result({q:m.answer(q,[oid])})
   self.assertEqual(next(t['weight'] for t in r['trace'] if t.get('option_id')==oid),v['w'])
 def test_08_no_se_suma_por_paisaje_duplicado(self):
  self.assertFalse(self.boost(self.result({'P03':m.answer('P03',16)}),'C3'))
 def test_09_c3_tres_paisajes(self):
  self.assertTrue(self.boost(self.result({'P02':m.answer('P02',7),'P06':m.answer('P06',4),'P13':m.answer('P13',7)}),'C3'))
 def test_10_c3_dos_mismo_paisaje(self):
  self.assertTrue(self.boost(self.result({'P13':m.answer('P13',7),'P14':m.answer('P14',7)}),'C3'))
 def test_11_c3_no_confunde_no_se_todavia(self):
  self.assertFalse(self.boost(self.result({'P01':m.answer('P01',6),'P24':m.answer('P24',17)}),'C3'))
 def test_12_prefiero_no_abre_cuidado(self):
  s=m.make_snapshot({'P16':m.answer('P16',8)});r=m.run(s)
  self.assertEqual(s['P17']['state_code'],'not_shown');self.assertEqual(s['P18']['state_code'],'not_shown')
  self.assertFalse(any(f['rule']=='C12' for f in r['floors']))
 def test_13_racha_prefiero_no_es_dano(self):
  r=self.result({'P16':m.answer('P16',8),'P33':m.answer('P33',8)})
  self.assertEqual([f['type'] for f in r['floors']],['w4-DEFERENCIA-PREFIERO'])
 def test_14_prefiero_fuera_cuidado(self):
  r=self.result({'P06':m.answer('P06',5),'P15':m.answer('P15',9)})
  self.assertFalse(r['floors']);self.assertEqual(len(r['flags']['PRIVACIDAD_CONJUNTO']),2)
 def test_15_cuidado_cinco_marcas(self):
  for oid in sorted(m.CARE):
   r=self.result({oid[:3]:m.answer(oid[:3],[oid])});self.assertTrue(any(f['rule']=='C12' for f in r['floors']))
 def test_16_p33_solo_dependencia_activa_cuidado(self):
  for i in range(1,6):self.assertEqual(any(f['rule']=='C12' for f in self.result({'P33':m.answer('P33',i)})['floors']),i==4)
 def test_17_p40_no_activa_cuidado_por_texto(self):
  r=self.result({'P40':m.answer('P40',txt='Siento miedo')});self.assertFalse(any(f['rule']=='C12' for f in r['floors']))
 def test_18_tres_pisos_factibles(self):
  r=self.result({'P16':m.answer('P16',5),'P17':m.answer('P17',8),'P18':m.answer('P18',6),'P12':m.answer('P12',1)})
  self.assertEqual({f['type'] for f in r['floors']},{'w4-CUIDADO','w4-DEFERENCIA-PREFIERO','w4-RELEVANCIA-P12'})
 def test_19_tres_pisos_ruta_imposible_rechazada(self):self.invalid({'P16':m.answer('P16',4),'P17':m.answer('P17',8),'P18':m.answer('P18',6)})
 def test_20_p12_relevancia_independiente_peso_p10(self):
  for i in [4,5,6]:
   r=self.result({'P10':m.answer('P10',i)});f=next(f for f in r['floors'] if f['rule']=='C38');self.assertEqual(f['branch_anchor'],[f'P10_O{i:02}'])
 def test_21_p12_externas_tambien_relevancia(self):
  for i in [7,8]:self.assertTrue(any(f['rule']=='C38' for f in self.result({'P12':m.answer('P12',i)})['floors']))
 def test_22_cp01_pares_exhaustivos(self):
  for a,b in itertools.combinations(range(1,7),2):
   r=self.result({'P01':m.answer('P01',[a,b])});self.assertEqual(self.hascp(r,'CP-01'),a==1 and b in {2,3,4,6})
 def test_23_cp02_no_convierte_cambio_en_malestar(self):
  self.assertFalse(self.hascp(self.result({'P01':m.answer('P01',3)}),'CP-02'))
 def test_24_cp02_fuentes_exactas(self):
  r=self.result({'P01':m.answer('P01',[4,5]),'P02':m.answer('P02',2)})
  self.assertEqual(next(t['option_ids'] for t in r['tensions'] if t['detector']=='CP-02'),['P01_O04','P02_O02'])
 def test_25_cp03_solo_frecuencia_alta(self):
  for n in range(1,7):
   r=self.result({'P08':m.answer('P08',n),'P09':m.answer('P09',4),'P10':m.answer('P10',2)})
   self.assertEqual(self.hascp(r,'CP-03'),n in {1,2})
 def test_26_cp03_poco_disfrute_igual_activa(self):
  self.assertTrue(self.hascp(self.result({'P08':m.answer('P08',1),'P09':m.answer('P09',1),'P10':m.answer('P10',4)}),'CP-03'))
 def test_27_responsivo_no_es_contradiccion(self):
  r=self.result({'P08':m.answer('P08',4),'P09':m.answer('P09',1),'P10':m.answer('P10',2)})
  self.assertFalse(self.hascp(r,'CP-03'));self.assertIn('2.3.01',r['readings'])
 def test_28_cp04_polos_cercania(self):
  r=self.result({'P13':m.answer('P13',1),'P14':m.answer('P14',4)});self.assertTrue(self.hascp(r,'CP-04'))
 def test_29_cp05_no_crea_p31(self):self.assertFalse(self.hascp(self.result(),'CP-05'))
 def test_30_cp06_respeta_pausa(self):
  r=self.result({'P01':m.answer('P01',4),'P24':m.answer('P24',15)})
  self.assertTrue(self.hascp(r,'CP-06'));self.assertIn('5.3.15',r['readings'])
 def test_31_cp06_no_arrastra_fuentes_irrelevantes(self):
  r=self.result({'P01':m.answer('P01',4),'P24':m.answer('P24',15)})
  self.assertEqual(next(t['option_ids'] for t in r['tensions'] if t['detector']=='CP-06'),['P01_O04','P24_O15'])
 def test_32_cp07_orgasmo(self):self.assertTrue(self.hascp(self.result({'P25':m.answer('P25',9)}),'CP-07'))
 def test_33_cp08_automatico_apagado(self):
  r=self.result({'P24':m.answer('P24',[7,9])});self.assertFalse(self.hascp(r,'CP-08'))
 def test_34_cp08_traza_entrante_bloquea(self):
  s=m.make_snapshot({'P24':m.answer('P24',[7,9])});r=m.run(s,[{'detector':'CP-08','option_ids':['P30_O01','P31_O01']}])
  self.assertFalse(r['filas_outcome_enabled']);self.assertFalse(self.boost(r,'C19'))
 def test_35_cp09_tabla_cerrada(self):
  for n in [3,4,5]:
   r=self.result({'P16':m.answer('P16',n),'P17':m.answer('P17',3)})
   self.assertEqual(self.hascp(r,'CP-09'),n in {4,5});self.assertTrue(any(f['rule']=='C12' for f in r['floors']))
 def test_36_cp10_no_todo_multi_tension(self):
  for a,b in itertools.combinations(range(1,7),2):
   r=self.result({'P12':m.answer('P12',[a,b])})
   self.assertEqual(self.hascp(r,'CP-10'),(a,b) in {(1,6),(3,4),(3,5),(4,6),(5,6)})
 def test_37_c19_una_vez(self):
  r=self.result({'P01':m.answer('P01',[1,4]),'P13':m.answer('P13',1),'P14':m.answer('P14',4)})
  self.assertGreaterEqual(len(r['tensions']),3);self.assertEqual(len(self.boost(r,'C19')),1)
 def test_38_carga_chips_no_canales(self):
  r=self.result({'P07':m.answer('P07',[12,13])});self.assertEqual(len(r['load_channels']),1);self.assertFalse(self.boost(r,'C17'))
 def test_39_p03_no_carga(self):
  r=self.result({'P03':m.answer('P03',[7,8,9,11,13])});self.assertFalse(r['load_channels'])
 def test_40_carga_cuatro_con_ancla(self):
  s=m.make_snapshot({'P07':m.answer('P07',1),'P20':m.answer('P20',7),'P33':m.answer('P33',1),'P32':m.answer('P32',5)})
  r=m.run(s,extra_load_channels=[{'question':'P32','option_ids':['P32_O05']}])
  self.assertEqual(self.boost(r,'C17')[0]['grade'],3);self.assertFalse(r['floors'])
 def test_41_canal_externo_sin_ancla_bloquea(self):
  r=m.run(m.make_snapshot(),extra_load_channels=[{'question':'P32','option_ids':['P32_O05']}]);self.assertFalse(r['filas_outcome_enabled'])
 def test_42_micro_privacidad_excluye_incertidumbre(self):self.invalid({'P03_MICRO':m.answer('P03_MICRO',[9,10])})
 def test_43_micro_otro_coexiste_y_texto(self):
  a=m.answer('P03_MICRO',[1,8]);a['text']=' Nombre exacto '
  r=self.result({'P03_MICRO':a});self.assertTrue(any(f['literal']==' Nombre exacto ' for f in r['filas']))
 def test_44_omision_p28_por_p01(self):self.assertEqual(m.make_snapshot({'P01':m.answer('P01',5),'P28':m.answer('P28',st='omitted')})['P28']['state_code'],'omitted')
 def test_45_omision_p28_por_p24_no(self):self.invalid({'P24':m.answer('P24',11),'P28':m.answer('P28',st='omitted')})
 def test_46_omision_p29_por_p22(self):self.assertEqual(m.make_snapshot({'P22':m.answer('P22',9),'P29':m.answer('P29',st='omitted')})['P29']['state_code'],'omitted')
 def test_47_omision_p29_por_p24_no(self):self.invalid({'P24':m.answer('P24',13),'P29':m.answer('P29',st='omitted')})
 def test_48_preguntas_no_mostradas_sin_fila(self):
  s=m.make_snapshot();r=m.run(s);shown={q for f in r['filas'] for q in f['preguntas']}
  self.assertFalse(shown & {q for q,a in s.items() if a['state_code']=='not_shown'})
 def test_49_omisiones_filas_distintas(self):
  r=self.result();self.assertTrue(all(any(f['preguntas']==[q] and f['tipo_fila']=='estado' for f in r['filas']) for q in ['P03','P11','P23']))
 def test_50_todas_nucleo_presentes(self):
  r=self.result();self.assertEqual({f['preguntas'][0] for f in r['filas'] if f['tipo_fila'] in {'respuesta','estado','voz_propia'} and f['grupo_situado']=='NUCLEO'},m.CORE)
 def test_51_base_orden_no_peso(self):
  r=self.result({'P13':m.answer('P13',5)});self.assertEqual([f['preguntas'][0] for f in r['filas'] if f['tipo_fila']=='respuesta' and f['grupo_situado']=='NUCLEO'],sorted(m.CORE))
 def test_52_cuidado_antes_texto_sin_borrarlo(self):
  r=self.result({'P16':m.answer('P16',5),'P23':m.answer('P23',txt='Quiero libertad')})
  f16=next(f for f in r['filas'] if f['preguntas']==['P16']);f23=next(f for f in r['filas'] if f['preguntas']==['P23'])
  self.assertLess(f16['orden_lenguaje'],f23['orden_lenguaje']);self.assertEqual(f23['literal'],'Quiero libertad')
 def test_53_datos_incompletos_no_inventan_respuesta(self):
  d={'session_id':'s','application_date':'2026-10-06','rules_version':m.RULE_VERSION,'instrument_version':m.RULES['instrument_version'],'snapshot':{'P01':m.answer('P01',1)}}
  self.assertFalse(m.process(d)['gate_complete']);self.assertEqual(m.process(d)['filas'],[])
 def test_54_version_incompatible_bloquea(self):
  d={'instrument_version':'v1.0','rules_version':m.RULE_VERSION};self.assertFalse(m.process(d)['filas_outcome_enabled'])
 def test_55_catalogo_sin_duplicados_y_fuente(self):
  self.assertEqual(len(m.READINGS),192);self.assertEqual(len({r['title'].casefold() for r in m.READINGS}),192)
  self.assertFalse(any(r['id']=='3.1.09' for r in m.READINGS))
 def test_56_lectura_manual_no_se_interpreta(self):
  r=self.result({'P23':m.answer('P23',txt='Miedo, alegría y pasión')});self.assertNotIn('5.2.03',r['readings'])
 def test_57_algo_no_borra_otras_lecturas(self):
  r=self.result({'P08':m.answer('P08',3),'P10':m.answer('P10',3)});self.assertIn('2.3.05',r['readings']);self.assertNotIn('2.3.10',r['readings'])
 def test_58_estado_literal_no_corresponde_rechazado(self):
  s=m.make_snapshot();s['P02']['state_code']='dont_know'
  with self.assertRaises(ValueError):m.validate(s)
 def test_59_opcion_otrapregunta_rechazada(self):
  s=m.make_snapshot();s['P02']['option_ids']=['P10_O02']
  with self.assertRaises(ValueError):m.validate(s)
 def test_60_zona_en_option_ids_rechazada(self):
  s=m.make_snapshot({'P11':m.answer('P11',['Z01'])});s['P11']['option_ids']=['Z01'];s['P11']['zone_ids']=[]
  with self.assertRaises(ValueError):m.validate(s)
 def test_61_tension_entrante_no_fabricada(self):
  r=m.run(m.make_snapshot(),[{'detector':'CP-02','option_ids':['P01_O01','P02_O02']}]);self.assertFalse(r['filas_outcome_enabled'])
 def test_62_no_score_ni_producto_final(self):
  r=self.result();self.assertNotIn('score',r);self.assertFalse(r['product_final']);self.assertIsNone(r['plan_lenguaje']['titulo_configuracion_completa'])
 def test_63_p17_huerfana_rechazada(self):self.invalid({'P16':m.answer('P16',8),'P17':m.answer('P17',1)})
 def test_64_maximo_y_exclusiones_p24(self):
  self.invalid({'P24':m.answer('P24',[1,15])});self.invalid({'P24':m.answer('P24',[1,2,3,4,5])})
 def test_65_tensiones_no_recuentan_boost_en_filas(self):
  r=self.result({'P01':m.answer('P01',[1,4]),'P13':m.answer('P13',1),'P14':m.answer('P14',4)})
  self.assertEqual(len(self.boost(r,'C19')),1);self.assertTrue(all(f['senal_w']==[{'route':'0_solo_traza','weight':0}] for f in r['filas'] if f['tipo_fila']=='tensión'))

if __name__=='__main__':unittest.main(verbosity=2)
