"""Barrido reproducible de entradas sintéticas. Sin datos de participantes."""
import collections, hashlib, itertools, json, unittest
from pathlib import Path
import motor_cartografia as m
ROOT=Path(__file__).resolve().parent

def envelope(s,sid):
 return {'session_id':sid,'application_date':'2026-10-06','instrument_version':m.RULES['instrument_version'],'rules_version':m.RULE_VERSION,'snapshot':s}

def examples():
 r1={'P08':m.answer('P08',3),'P09':m.answer('P09',3),'P13':m.answer('P13',2),'P14':m.answer('P14',2),'P15':m.answer('P15',2),'P22':m.answer('P22',1),'P24':m.answer('P24',1),'P01':m.answer('P01',4),'P02':m.answer('P02',2),'P06':m.answer('P06',1),'P07':m.answer('P07',13),
     'P10':m.answer('P10',2),'P16':m.answer('P16',8),'P19':m.answer('P19',4),'P20':m.answer('P20',[7,2]),
     'P21':m.answer('P21',4),'P33':m.answer('P33',8),'P03':m.answer('P03',st='omitted'),'P11':m.answer('P11',st='omitted'),
     'P23':m.answer('P23',txt='[TEXTO DE EJEMPLO DE SIMULACIÓN] Quiero tener tiempo para mí y volver a sentir ganas, sin presión.')}
 cases={
  'R1_COMPLETADO_SINTETICO':r1,
  'RESPONSIVO':{'P08':m.answer('P08',4),'P09':m.answer('P09',1),'P10':m.answer('P10',2)},
  'SIN_ENCUENTROS':{'P08':m.answer('P08',6),'P09':m.answer('P09',6),'P10':m.answer('P10',8),'P15':m.answer('P15',7)},
  'TRES_PISOS':{'P16':m.answer('P16',5),'P17':m.answer('P17',8),'P18':m.answer('P18',6),'P12':m.answer('P12',1)},
  'G3_P12':{'P10':m.answer('P10',4),'P12':m.answer('P12',[3,4])},
  'MULTIPLES_TENSIONES':{'P01':m.answer('P01',[1,4]),'P13':m.answer('P13',1),'P14':m.answer('P14',4)},
  'OMISION_P28_POR_P01':{'P01':m.answer('P01',5),'P28':m.answer('P28',st='omitted')},
  'OMISION_P29_POR_P22':{'P22':m.answer('P22',9),'P29':m.answer('P29',st='omitted')},
  'TEXTO_LITERAL':{'P23':m.answer('P23',txt='  <script>alert("texto")</script>\n Yo & mi deseo.  ')}}
 for sid,f in cases.items():
  data=envelope(m.make_snapshot(f),sid)
  if sid=='R1_COMPLETADO_SINTETICO':data['qa_note']='El documento Filas v2 no declara los valores de P08 P09 P13 P14 P15 P22 P24. Se completaron solo para un ejemplo sintético reproducible, sin atribuirlos al R1 original.'
  (ROOT/'ejemplos'/f'{sid}_entrada.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
  (ROOT/'ejemplos'/f'{sid}_salida.json').write_text(json.dumps(m.process(data),ensure_ascii=False,indent=2),encoding='utf-8')
 return cases

def main():
 m.load_sources();counts=collections.Counter();coverage=collections.Counter();digest=hashlib.sha256();review=collections.Counter();witness={};rowcount=0
 def consume(label,forced):
  nonlocal rowcount
  try:s=m.make_snapshot(forced)
  except ValueError:counts[label+'_invalida']+=1;return
  r=m.run(s)
  # Every presented question appears exactly once in a literal/state row.
  base=[f for f in r['filas'] if f['tipo_fila'] in {'respuesta','estado','voz_propia'} and not f['fila_id'].endswith('P03_MICRO:voz_propia')]
  assert {f['preguntas'][0] for f in base}=={q for q,a in s.items() if a['state_code']!='not_shown'}
  assert len(base)==len({f['preguntas'][0] for f in base})
  assert all(f['trazabilidad']=='completa' and f['ancla'] for f in r['filas'])
  assert r['assert_P_S4'] and r['filas_outcome_enabled'] and not r['review_required']
  assert not any(t['detector']=='CP-08' for t in r['tensions'])
  counts[label]+=1;rowcount+=len(r['filas'])
  digest.update(json.dumps({'answers':s,'result':r},sort_keys=True,ensure_ascii=False).encode())
  for rid in r['readings']:
   coverage[rid]+=1
   if rid not in witness:witness[rid]=envelope(s,'TESTIGO_'+rid)
  for e in r['review_required']:review[e['reason']]+=1
 for q in sorted(m.QMAP):
  for a in m.domain(q):consume('variaciones_por_pregunta',{q:a})
 crosses={}
 for qs in [('P01','P02'),('P08','P09','P10'),('P13','P14'),('P15','P31')]:
  cname='_'.join(qs);rows=[]
  for aa in itertools.product(*[[a for a in m.domain(q) if a['state_code']!='omitted'] for q in qs]):
   f=dict(zip(qs,aa));consume('cruce_'+cname,f);s=m.make_snapshot(f);r=m.run(s)
   rows.append({'id':cname+f'.{len(rows)+1:03}','respuestas':{q:[m.OPT[i]['label'] for i in s[q]['option_ids']] for q in qs},
                'lecturas':[{'id':x['id'],'titulo_base':x['title']} for x in m.READINGS if x['id'] in r['readings'] and set(x['questions'])&set(qs)],
                'tensiones':[t for t in r['tensions'] if set(t['questions'])&set(qs)]})
  crosses[cname]=rows
 care=[]
 for p16 in m.domain('P16'):
  ss=m.make_snapshot({'P16':p16})
  for p17 in m.domain('P17') if m.active(ss,'P17') else [m.answer('P17',st='not_shown')]:
   ss=m.make_snapshot({'P16':p16,'P17':p17})
   for p18 in m.domain('P18') if m.active(ss,'P18') else [m.answer('P18',st='not_shown')]:
    f={'P16':p16,'P17':p17,'P18':p18};consume('rutas_cuidado',f);r=m.run(m.make_snapshot(f))
    care.append({'id':f'CUIDADO.{len(care)+1:03}','respuestas':f,'pisos':r['floors'],'tensiones':r['tensions']})
 crosses['P16_P17_P18']=care
 cases=examples()
 for sid,f in cases.items():consume('casos_integrados',f)
 suite=unittest.defaultTestLoader.discover(str(ROOT),pattern='test_motor.py')
 testresult=unittest.TestResult();suite.run(testresult)
 if testresult.failures or testresult.errors:raise AssertionError(str(testresult.failures+testresult.errors))
 report={'version':m.RULE_VERSION,'status':'PASS','freeze_scope':'MOTOR HASTA FILAS OUTCOME','counts':dict(counts),
  'synthetic_valid_inputs':sum(v for k,v in counts.items() if not k.endswith('_invalida')),'literal_rows_and_derived_rows_checked':rowcount,
  'automatic_readings':len(coverage),'catalog_readings':len(m.READINGS),'manual_readings':['5.2.03'],
  'unreached':[x['id'] for x in m.READINGS if x['id'] not in coverage], 'coverage':dict(coverage),
  'blocking_review_on_valid_generated_inputs':dict(review),'functional_tests':testresult.testsRun,'failures':0,
  'output_digest':digest.hexdigest(),'full_global_cartesian_product_tested':False,'participant_data_used':False,
  'nicolas_program_or_interface_tested':False,'final_product':False}
 (ROOT/'verificacion/informe_corrida.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'verificacion/testigos_lecturas.json').write_text(json.dumps(witness,ensure_ascii=False,indent=2),encoding='utf-8')
 (ROOT/'verificacion/cruces_locales.json').write_text(json.dumps(crosses,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:v for k,v in report.items() if k!='coverage'},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
