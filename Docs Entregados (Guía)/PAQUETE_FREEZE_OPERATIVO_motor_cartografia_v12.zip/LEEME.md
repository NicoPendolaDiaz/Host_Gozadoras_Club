# 1 Paquete motor de cartografía V12

FREEZE OPERATIVO hasta Filas outcome. Corte único vigente de 6 de octubre de 2026. No es FINAL del MVP, ni generador de prosa final o Destinos.

## 2 Qué leer

1. documentos/Motor_y_Filas_FREEZE_V12.docx: contrato para integrar el motor.
2. documentos/Listas_base_configuraciones_V12.docx: 192 componentes numerados por variable y paisaje, con preguntas de origen.
3. documentos/Comparacion_Filas_y_Cartografia_V12.docx: comparación con el documento adjunto y decisiones de corrección.
4. documentos/Instrumento_motor_V12.txt: preguntas y opciones vigentes que consume esta versión.

## 3 Ejecutar

Python 3.10 o posterior. No requiere instalación de dependencias.

```sh
python3 motor_cartografia.py --entrada ejemplos/R1_COMPLETADO_SINTETICO_entrada.json --salida salida.json
python3 -m unittest -v test_motor.py
python3 verificar_corrida.py
```

También puede importarse motor_cartografia, llamar load_sources una vez y process con la entrada. El resultado sale como un objeto JSON. No usar make_snapshot ni answer para completar datos reales; construyen entradas de prueba.

## 4 Identidades y entrada

instrument_version = INSTRUMENTO-CARTOGRAFIA-12. rules_version = MOTOR-CARTOGRAFIA-12. Conservar session_id y application_date. snapshot contiene P01 a P40 y P03_MICRO. Los ejemplos muestran el formato completo. not_shown se conserva internamente y no genera fila. Una entrada incompleta o incompatible se bloquea; nunca se completa con una respuesta inventada.

Los resultados antiguos conservan sus versiones originales. No sobrescribirlos ni asignarles esta versión de reglas. Para reanalizarlos se necesita una entrada completa y una nueva salida identificada como reanálisis, preservando la original.

## 5 Salida

filas contiene respuestas, omisiones, palabras propias, tensiones y conjuntos con su origen. orden_base sigue Situado; orden_lenguaje aplica pisos y relaciones sin borrar contenido. plan_lenguaje guarda las referencias en ese orden. max_individual, boosts y pisos son campos separados; no sumarlos para crear un score.

estado_snapshot operativo habilita Filas outcome. REVIEW_REQUIRED las bloquea y devuelve motivos. Una salida bloqueada con filas internas solo sirve para revisar trazas; no mostrarla como resultado personalizado. CLI termina con 0 en operativo y 2 en bloqueado.

## 6 Particularidades cerradas

P08_O06 = No he tenido últimamente. P10_O08 y P15_O07 usan el mismo texto. C8 de ausencia = w1 y freno, no deseo bajo. Medicamentos M09/M10 son mutuamente excluyentes. CP08 y C29 apagados. 5.2.03 es lectura humana, no inferencia automática. P28/P29 son omisibles solo con su puerta enriquecedora.

Los textos se guardan exactos y se muestran como texto, nunca como HTML ejecutable. No recortar o reformular la voz propia. Las preguntas múltiples presentan grupos en una pantalla, con un máximo de selección global.

## 7 Evidencia

verificacion/informe_corrida.json contiene el alcance y las cifras. verificacion/testigos_lecturas.json conserva una entrada válida por lectura automática. verificacion/cruces_locales.json muestra las combinaciones locales probadas. ejemplos incluye casos completos sintéticos y sus salidas.

R1_COMPLETADO_SINTETICO añade explícitamente siete respuestas que el documento adjunto no indicaba. No es una participante ni una reproducción literal de datos ausentes. No incluye históricos ni Sheet de resultados.
